import 'package:flutter/material.dart';
import '../models/models.dart';

class AppProvider extends ChangeNotifier {
  AppUser? _currentUser;
  List<AppUser> _workers = [];
  List<RoomListing> _rooms = [];
  List<Lead> _leads = [];
  List<ChatConversation> _conversations = [];
  Map<String, List<ChatMessage>> _messages = {};
  bool _isLoading = false;
  String? _error;

  AppUser? get currentUser => _currentUser;
  List<AppUser> get workers => _workers;
  List<RoomListing> get rooms => _rooms;
  List<Lead> get leads => _leads;
  List<ChatConversation> get conversations => _conversations;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _currentUser != null;

  void init() {
    _workers = getMockWorkers();
    _rooms = getMockRooms();
    _leads = getMockLeads();
    _initMockConversations();
  }

  void _initMockConversations() {
    _conversations = [
      ChatConversation(
        id: 'c1',
        otherUserId: 'w1',
        otherUserName: 'Ramesh Kumar',
        otherUserRole: 'मजदूर',
        otherUserPhone: '9876543210',
        lastMessage: 'ठीक है भाई, कल आ जाऊंगा।',
        lastMessageAt: DateTime.now().subtract(const Duration(minutes: 30)),
        unreadCount: 2,
      ),
      ChatConversation(
        id: 'c2',
        otherUserId: 'w2',
        otherUserName: 'Suresh Yadav',
        otherUserRole: 'ठेकेदार',
        otherUserPhone: '9123456780',
        lastMessage: 'Site कहाँ है? Address भेजो।',
        lastMessageAt: DateTime.now().subtract(const Duration(hours: 2)),
        unreadCount: 0,
      ),
    ];
    _messages['c1'] = [
      ChatMessage(
        id: 'm1',
        senderId: 'w1',
        receiverId: 'current',
        message: 'नमस्ते जी, काम के बारे में बात करनी थी।',
        sentAt: DateTime.now().subtract(const Duration(hours: 1)),
      ),
      ChatMessage(
        id: 'm2',
        senderId: 'current',
        receiverId: 'w1',
        message: 'हाँ भाई, बोलो। कल से काम शुरू कर सकते हो?',
        sentAt: DateTime.now().subtract(const Duration(minutes: 45)),
      ),
      ChatMessage(
        id: 'm3',
        senderId: 'w1',
        receiverId: 'current',
        message: 'ठीक है भाई, कल आ जाऊंगा।',
        sentAt: DateTime.now().subtract(const Duration(minutes: 30)),
        isRead: false,
      ),
    ];
  }

  // ── Auth ──────────────────────────────────
  void sendOtp(String phone) {
    // In real app: Firebase Auth or SMS gateway
    notifyListeners();
  }

  void verifyOtp(String otp, String phone) {
    // In real app: verify with Firebase
    // For demo, any OTP works
    _currentUser = AppUser(
      id: 'user_${DateTime.now().millisecondsSinceEpoch}',
      name: '',
      phone: phone,
      role: UserRole.worker,
      verificationStatus: VerificationStatus.notStarted,
      freeCallsLeft: 2,
      freeChatsLeft: 3,
    );
    notifyListeners();
  }

  void setUserRole(UserRole role) {
    if (_currentUser != null) {
      _currentUser!.role = role;
      notifyListeners();
    }
  }

  void setUserName(String name) {
    if (_currentUser != null) {
      _currentUser!.name = name;
      notifyListeners();
    }
  }

  void setUserLocation(String city, String state, double? lat, double? lng) {
    if (_currentUser != null) {
      _currentUser!.city = city;
      _currentUser!.state = state;
      _currentUser!.latitude = lat;
      _currentUser!.longitude = lng;
      notifyListeners();
    }
  }

  void acceptPrivacyPolicy() {
    if (_currentUser != null) {
      _currentUser!.hasAcceptedPrivacyPolicy = true;
      notifyListeners();
    }
  }

  void submitKyc({
    required String idProofType,
    required String idProofPath,
    required String selfiePhotoPath,
  }) {
    if (_currentUser != null) {
      _currentUser!.idProofType = idProofType;
      _currentUser!.idProofPath = idProofPath;
      _currentUser!.selfiePhotoPath = selfiePhotoPath;
      _currentUser!.verificationStatus = VerificationStatus.pending;
      _currentUser!.kycSubmittedAt = DateTime.now();
      notifyListeners();
    }
  }

  void setWorkerSkills(List<WorkSkill> skills, bool isAvailable) {
    if (_currentUser != null) {
      _currentUser!.skills = skills;
      _currentUser!.isAvailableForWork = isAvailable;
      notifyListeners();
    }
  }

  void toggleOnlineStatus() {
    if (_currentUser != null) {
      _currentUser!.isOnline = !_currentUser!.isOnline;
      notifyListeners();
    }
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  // ── Workers ──────────────────────────────
  List<AppUser> searchWorkers({
    String? query,
    WorkSkill? skill,
    String? city,
    bool onlyAvailable = false,
    bool onlyOnline = false,
  }) {
    return _workers.where((w) {
      if (onlyAvailable && !w.isAvailableForWork) return false;
      if (onlyOnline && !w.isOnline) return false;
      if (skill != null && !w.skills.contains(skill)) return false;
      if (city != null && city.isNotEmpty &&
          !(w.city?.toLowerCase().contains(city.toLowerCase()) ?? false)) {
        return false;
      }
      if (query != null && query.isNotEmpty) {
        final q = query.toLowerCase();
        if (!w.name.toLowerCase().contains(q) &&
            !(w.city?.toLowerCase().contains(q) ?? false) &&
            !w.skills.any((s) => s.label.toLowerCase().contains(q))) {
          return false;
        }
      }
      return true;
    }).toList();
  }

  // ── Rooms ────────────────────────────────
  List<RoomListing> getPublicRooms({String? city}) {
    return _rooms.where((r) {
      if (r.status != RoomStatus.published) return false;
      if (city != null && city.isNotEmpty &&
          !r.city.toLowerCase().contains(city.toLowerCase())) return false;
      return true;
    }).toList();
  }

  List<RoomListing> getMyRooms() {
    if (_currentUser == null) return [];
    return _rooms.where((r) => r.ownerId == _currentUser!.id).toList();
  }

  void addRoom(RoomListing room) {
    _rooms.add(room);
    notifyListeners();
  }

  void publishRoom(String roomId) {
    final idx = _rooms.indexWhere((r) => r.id == roomId);
    if (idx != -1) {
      _rooms[idx].status = RoomStatus.published;
      _rooms[idx].publishedAt = DateTime.now();
      _rooms[idx].expiresAt = DateTime.now().add(const Duration(days: 10));
      notifyListeners();
    }
  }

  // ── Calls ────────────────────────────────
  bool canMakeCall() {
    if (_currentUser == null) return false;
    if (!_currentUser!.isVerified) return false;
    return _currentUser!.freeCallsLeft > 0 || _currentUser!.walletBalance >= 100;
  }

  void useCall() {
    if (_currentUser == null) return;
    if (_currentUser!.freeCallsLeft > 0) {
      _currentUser!.freeCallsLeft--;
    } else {
      _currentUser!.walletBalance -= 100; // ₹1 per call
    }
    notifyListeners();
  }

  // ── Chat ─────────────────────────────────
  bool canSendChat() {
    if (_currentUser == null) return false;
    if (!_currentUser!.isVerified) return false;
    return _currentUser!.freeChatsLeft > 0 || _currentUser!.walletBalance >= 50;
  }

  void sendMessage(String conversationId, String message) {
    if (_currentUser == null) return;
    final msg = ChatMessage(
      id: 'msg_${DateTime.now().millisecondsSinceEpoch}',
      senderId: _currentUser!.id,
      receiverId: conversationId,
      message: message,
    );
    _messages[conversationId] = [...(_messages[conversationId] ?? []), msg];

    // update conversation
    final idx = _conversations.indexWhere((c) => c.id == conversationId);
    if (idx != -1) {
      _conversations[idx].lastMessage = message;
      _conversations[idx].lastMessageAt = DateTime.now();
    }

    if (_currentUser!.freeChatsLeft > 0) {
      _currentUser!.freeChatsLeft--;
    }
    notifyListeners();
  }

  List<ChatMessage> getMessages(String conversationId) {
    return _messages[conversationId] ?? [];
  }

  void startConversation(AppUser otherUser) {
    final exists = _conversations.any((c) => c.otherUserId == otherUser.id);
    if (!exists) {
      _conversations.insert(
        0,
        ChatConversation(
          id: 'c_${DateTime.now().millisecondsSinceEpoch}',
          otherUserId: otherUser.id,
          otherUserName: otherUser.name,
          otherUserRole: otherUser.roleLabel,
          otherUserPhone: otherUser.phone,
        ),
      );
      notifyListeners();
    }
  }

  // ── Leads ────────────────────────────────
  bool purchaseLead(String leadId) {
    if (_currentUser == null) return false;
    if (_currentUser!.walletBalance < 200) return false; // ₹2
    _currentUser!.walletBalance -= 200;
    final idx = _leads.indexWhere((l) => l.id == leadId);
    if (idx != -1) {
      _leads[idx].purchasedLeads++;
    }
    notifyListeners();
    return true;
  }

  // ── Wallet / Payment ─────────────────────
  void addWalletBalance(int amountInRupees) {
    if (_currentUser == null) return;
    _currentUser!.walletBalance += amountInRupees * 100; // convert to paise
    notifyListeners();
  }

  void purchaseSubscription(SubscriptionPlan plan) {
    if (_currentUser == null) return;
    _currentUser!.freeCallsLeft += plan.callsIncluded;
    _currentUser!.freeChatsLeft += plan.chatsIncluded;
    if (plan.id == 'premium') {
      _currentUser!.verificationStatus = VerificationStatus.verified;
    }
    notifyListeners();
  }
}
