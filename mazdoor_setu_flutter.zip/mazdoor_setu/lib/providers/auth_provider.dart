import 'package:flutter/material.dart';
import '../models/user_model.dart';

enum AuthState { initial, loading, authenticated, unauthenticated, error }

class AuthProvider extends ChangeNotifier {
  AuthState _authState = AuthState.initial;
  UserModel? _currentUser;
  String? _errorMessage;
  String? _verificationId;
  bool _isLoading = false;

  AuthState get authState => _authState;
  UserModel? get currentUser => _currentUser;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;
  bool get isVerified => _currentUser?.isVerified ?? false;

  // ===================== OTP SEND =====================
  Future<bool> sendOTP(String phoneNumber) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Firebase Phone Auth - sendVerificationCode
      // await FirebaseAuth.instance.verifyPhoneNumber(
      //   phoneNumber: '+91$phoneNumber',
      //   verificationCompleted: (credential) async { ... },
      //   verificationFailed: (e) { ... },
      //   codeSent: (verificationId, resendToken) {
      //     _verificationId = verificationId;
      //   },
      //   codeAutoRetrievalTimeout: (verificationId) { ... },
      // );

      // DEMO: Simulate OTP sent
      await Future.delayed(const Duration(seconds: 1));
      _verificationId = 'demo_verification_id';
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'OTP भेजने में समस्या हुई। दोबारा कोशिश करें।';
      notifyListeners();
      return false;
    }
  }

  // ===================== OTP VERIFY =====================
  Future<bool> verifyOTP(String otp, String phone) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // DEMO: Accept any 6-digit OTP
      await Future.delayed(const Duration(seconds: 1));

      if (otp.length == 6) {
        // Check if user exists in Firestore
        // DocumentSnapshot doc = await FirebaseFirestore.instance
        //     .collection('users').doc(uid).get();

        // DEMO: Create a new user or load existing
        _currentUser = UserModel(
          uid: 'demo_uid_${phone.substring(7)}',
          name: '',
          phone: phone,
          role: UserRole.worker,
          verificationStatus: VerificationStatus.notStarted,
          createdAt: DateTime.now(),
        );

        _authState = AuthState.authenticated;
        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'गलत OTP दर्ज किया। दोबारा कोशिश करें।';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Verification विफल हुई।';
      notifyListeners();
      return false;
    }
  }

  // ===================== SET ROLE & NAME =====================
  Future<void> setUserRoleAndName(String name, UserRole role) async {
    if (_currentUser == null) return;
    _isLoading = true;
    notifyListeners();

    _currentUser = _currentUser!.copyWith(name: name);
    _currentUser = UserModel(
      uid: _currentUser!.uid,
      name: name,
      phone: _currentUser!.phone,
      role: role,
      verificationStatus: _currentUser!.verificationStatus,
      createdAt: _currentUser!.createdAt,
    );

    // Save to Firestore
    // await FirebaseFirestore.instance
    //     .collection('users')
    //     .doc(_currentUser!.uid)
    //     .set(_currentUser!.toMap());

    await Future.delayed(const Duration(milliseconds: 500));
    _isLoading = false;
    notifyListeners();
  }

  // ===================== KYC SUBMIT =====================
  Future<bool> submitKYC({
    required String aadharPath,
    required String selfiePath,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Upload to Firebase Storage
      // final aadharRef = FirebaseStorage.instance.ref('kyc/${_currentUser!.uid}/aadhar.jpg');
      // await aadharRef.putFile(File(aadharPath));
      // final aadharUrl = await aadharRef.getDownloadURL();

      await Future.delayed(const Duration(seconds: 2));

      _currentUser = _currentUser?.copyWith(
        verificationStatus: VerificationStatus.pending,
        aadharUrl: 'uploaded_aadhar_url',
        selfieUrl: 'uploaded_selfie_url',
      );

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Document upload failed';
      notifyListeners();
      return false;
    }
  }

  // ===================== UPDATE PROFILE =====================
  Future<void> updateProfile({
    String? name,
    String? bio,
    List<String>? skills,
    bool? isAvailableForWork,
    String? location,
    double? latitude,
    double? longitude,
  }) async {
    if (_currentUser == null) return;

    _currentUser = _currentUser!.copyWith(
      name: name,
      bio: bio,
      skills: skills,
      isAvailableForWork: isAvailableForWork,
      location: location,
      latitude: latitude,
      longitude: longitude,
    );

    // await FirebaseFirestore.instance
    //     .collection('users')
    //     .doc(_currentUser!.uid)
    //     .update(_currentUser!.toMap());

    notifyListeners();
  }

  // ===================== TOGGLE ONLINE STATUS =====================
  Future<void> toggleOnlineStatus(bool isOnline) async {
    if (_currentUser == null) return;
    _currentUser = _currentUser!.copyWith(isOnline: isOnline);
    notifyListeners();
  }

  // ===================== DECREMENT FREE CALL =====================
  bool canMakeCall() {
    if (!isVerified) return false;
    return (_currentUser?.freeCallsLeft ?? 0) > 0 || (_currentUser?.walletBalance ?? 0) > 0;
  }

  void decrementFreeCall() {
    if (_currentUser == null) return;
    final left = _currentUser!.freeCallsLeft;
    if (left > 0) {
      _currentUser = _currentUser!.copyWith(freeCallsLeft: left - 1);
      notifyListeners();
    }
  }

  // ===================== DECREMENT FREE CHAT =====================
  bool canChat() {
    if (!isVerified) return false;
    return (_currentUser?.freeChatsLeft ?? 0) > 0 || (_currentUser?.walletBalance ?? 0) > 0;
  }

  void decrementFreeChat() {
    if (_currentUser == null) return;
    final left = _currentUser!.freeChatsLeft;
    if (left > 0) {
      _currentUser = _currentUser!.copyWith(freeChatsLeft: left - 1);
      notifyListeners();
    }
  }

  // ===================== ADD WALLET BALANCE =====================
  void addWalletBalance(int amount) {
    if (_currentUser == null) return;
    _currentUser = _currentUser!.copyWith(
      walletBalance: (_currentUser!.walletBalance + amount),
    );
    notifyListeners();
  }

  // ===================== SIGN OUT =====================
  Future<void> signOut() async {
    // await FirebaseAuth.instance.signOut();
    _currentUser = null;
    _authState = AuthState.unauthenticated;
    notifyListeners();
  }
}
