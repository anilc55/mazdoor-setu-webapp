import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class RoomListingScreen extends StatefulWidget {
  const RoomListingScreen({super.key});
  @override
  State<RoomListingScreen> createState() => _RoomListingScreenState();
}

class _RoomListingScreenState extends State<RoomListingScreen> {
  String _selectedType = 'सभी';
  RangeValues _priceRange = const RangeValues(0, 10000);

  final _demoRooms = [
    {'title': 'सिंगल रूम उपलब्ध', 'type': 'Single', 'location': 'करोल बाग, दिल्ली', 'rent': 3000, 'facilities': ['पानी', 'बिजली', 'WiFi', 'Bathroom'], 'owner': 'सतीश शर्मा', 'phone': '9876543210', 'isPublic': true, 'daysLeft': 8},
    {'title': 'PG – Male Only', 'type': 'PG', 'location': 'अंधेरी वेस्ट, मुंबई', 'rent': 5500, 'facilities': ['AC', 'Kitchen', 'Laundry', 'WiFi'], 'owner': 'नीता देसाई', 'phone': '9876500001', 'isPublic': true, 'daysLeft': 25},
    {'title': 'शेयर्ड रूम – 2 लोग', 'type': 'Shared', 'location': 'मालवीय नगर, जयपुर', 'rent': 2000, 'facilities': ['पंखा', 'बिजली', 'Bathroom'], 'owner': 'गोपाल मीणा', 'phone': '9876500002', 'isPublic': true, 'daysLeft': 5},
    {'title': 'फैमिली रूम – 2BHK', 'type': 'Family', 'location': 'इंदिरानगर, लखनऊ', 'rent': 8000, 'facilities': ['AC', 'पार्किंग', 'WiFi', 'CCTV'], 'owner': 'राजेश वर्मा', 'phone': '9876500003', 'isPublic': false, 'daysLeft': 18},
    {'title': 'सस्ता PG कमरा', 'type': 'PG', 'location': 'हडपसर, पुणे', 'rent': 3500, 'facilities': ['पानी', 'बिजली', 'किचन'], 'owner': 'प्रकाश पाटिल', 'phone': '9876500004', 'isPublic': true, 'daysLeft': 3},
  ];

  void _handleCall(BuildContext context, Map<String, dynamic> room) {
    final auth = context.read<AuthProvider>();
    if (!auth.isVerified) { VerifyPopup.show(context); return; }
    if (!auth.canMakeCall()) { Navigator.pushNamed(context, '/payment'); return; }
    auth.decrementFreeCall();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Calling ${room['owner']}...'), backgroundColor: AppColors.success));
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final isRoomOwner = auth.currentUser?.role.name == 'roomOwner';

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(
        title: const Text('किराये के रूम'),
        backgroundColor: AppColors.primaryGreen,
        actions: [
          if (isRoomOwner)
            TextButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/add-room'),
              icon: const Icon(Icons.add, color: Colors.white, size: 18),
              label: const Text('Add', style: TextStyle(color: Colors.white))),
          IconButton(icon: const Icon(Icons.filter_list), onPressed: () {}),
        ],
      ),
      body: Column(children: [
        // Type filter
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: ['सभी', 'Single', 'Shared', 'PG', 'Family'].map((t) =>
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(t, style: TextStyle(fontSize: 12, color: _selectedType == t ? Colors.white : AppColors.darkGrey)),
                  selected: _selectedType == t,
                  onSelected: (_) => setState(() => _selectedType = t),
                  selectedColor: AppColors.primaryGreen,
                  backgroundColor: AppColors.lightGrey,
                ),
              )).toList()),
          ),
        ),

        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: _demoRooms.length,
            itemBuilder: (_, i) {
              final r = _demoRooms[i];
              final isPublic = r['isPublic'] as bool;
              final daysLeft = r['daysLeft'] as int;
              final facilities = r['facilities'] as List<String>;

              return GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/room-detail', arguments: r),
                child: Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 2,
                  child: Column(children: [
                    // Photo placeholder
                    Stack(children: [
                      Container(
                        height: 130, width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [AppColors.primaryGreen.withOpacity(0.15), AppColors.primaryGreen.withOpacity(0.05)]),
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(16))),
                        child: isPublic
                          ? const Center(child: Icon(Icons.home, size: 60, color: AppColors.primaryGreen))
                          : Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              const Icon(Icons.lock, size: 40, color: AppColors.grey),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(color: AppColors.grey.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
                                child: const Text('Locked – Verify करें', style: TextStyle(color: AppColors.grey))),
                            ])),
                      ),
                      // Days left badge
                      Positioned(top: 10, right: 10,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: daysLeft <= 3 ? AppColors.error : AppColors.primaryGreen,
                            borderRadius: BorderRadius.circular(8)),
                          child: Text('$daysLeft दिन बचे', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)))),
                      // Type badge
                      Positioned(top: 10, left: 10,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
                          child: Text(r['type'].toString(), style: const TextStyle(color: Colors.white, fontSize: 11)))),
                    ]),

                    Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text(r['title'].toString(), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold))),
                          Text('₹${r['rent']}/माह', style: const TextStyle(color: AppColors.primaryOrange, fontWeight: FontWeight.bold, fontSize: 15)),
                        ]),
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.location_on, size: 13, color: AppColors.grey),
                          Text(r['location'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                        ]),
                        const SizedBox(height: 8),
                        // Facilities chips
                        Wrap(spacing: 6, runSpacing: 4, children: facilities.take(4).map((f) =>
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: AppColors.offWhite, borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: AppColors.lightGrey)),
                            child: Text(f, style: const TextStyle(fontSize: 11, color: AppColors.darkGrey)))).toList()),
                        const SizedBox(height: 12),
                        Row(children: [
                          Expanded(child: OutlinedButton.icon(
                            onPressed: () => _handleCall(context, r),
                            icon: const Icon(Icons.phone, size: 15),
                            label: const Text('Call Owner'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.primaryGreen,
                              side: const BorderSide(color: AppColors.primaryGreen),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                          )),
                          const SizedBox(width: 10),
                          Expanded(child: ElevatedButton.icon(
                            onPressed: () => Navigator.pushNamed(context, '/room-detail', arguments: r),
                            icon: const Icon(Icons.visibility, size: 15),
                            label: const Text('Details'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primaryGreen,
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                          )),
                        ]),
                      ]),
                    ),
                  ]),
                ),
              );
            },
          ),
        ),
      ]),
      floatingActionButton: isRoomOwner
        ? FloatingActionButton.extended(
            onPressed: () => Navigator.pushNamed(context, '/add-room'),
            backgroundColor: AppColors.primaryOrange,
            icon: const Icon(Icons.add_home, color: Colors.white),
            label: const Text('रूम Add करें', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))
        : null,
    );
  }
}
