import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class LeadScreen extends StatefulWidget {
  const LeadScreen({super.key});
  @override
  State<LeadScreen> createState() => _LeadScreenState();
}

class _LeadScreenState extends State<LeadScreen> {
  String _selectedType = 'सभी';

  final _demoLeads = [
    {'type': 'मजदूर चाहिए', 'title': '10 राजमिस्त्री चाहिए', 'desc': 'दिल्ली में बड़ा construction project। 6 महीने काम।', 'location': 'नोएडा, UP', 'budget': '₹600/दिन', 'postedBy': 'अजय कंस्ट्रक्शन', 'icon': '🧱', 'purchased': false},
    {'type': 'रूम चाहिए', 'title': 'सिंगल रूम चाहिए', 'desc': 'Working bachelor के लिए। Budget ₹3000-4000।', 'location': 'करोल बाग, दिल्ली', 'budget': '₹3000-4000/माह', 'postedBy': 'महेश कुमार', 'icon': '🏠', 'purchased': false},
    {'type': 'जमीन खरीदनी है', 'title': '5 बीघा खेती की जमीन', 'desc': 'पानी की सुविधा हो। Road connectivity जरूरी।', 'location': 'रोहतक, हरियाणा', 'budget': '₹15-20 लाख', 'postedBy': 'किसान सेवा ग्रुप', 'icon': '🌾', 'purchased': true},
    {'type': 'घर खरीदना है', 'title': '2BHK घर चाहिए', 'desc': 'School के पास। Loan available है।', 'location': 'जयपुर', 'budget': '₹25-30 लाख', 'postedBy': 'प्रिया शर्मा', 'icon': '🏡', 'purchased': false},
    {'type': 'मजदूर चाहिए', 'title': 'Electrician चाहिए', 'desc': 'Factory wiring का काम। तुरंत चाहिए।', 'location': 'सूरत, Gujarat', 'budget': '₹700/दिन', 'postedBy': 'Mehta Industries', 'icon': '⚡', 'purchased': false},
  ];

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final filtered = _selectedType == 'सभी' ? _demoLeads
      : _demoLeads.where((l) => l['type'] == _selectedType).toList();

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(title: const Text('Leads'), backgroundColor: AppColors.primaryGreen),
      body: Column(children: [
        // Header
        Container(
          color: AppColors.primaryGreen,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            const Expanded(child: Text('🎯 ₹2 per lead — Verified Contacts',
              style: TextStyle(color: Colors.white70, fontSize: 13))),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/payment',
                arguments: {'tab': 1}),
              child: const Text('Pack खरीदें →', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
          ]),
        ),

        // Filter chips
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: ['सभी', 'मजदूर चाहिए', 'रूम चाहिए', 'जमीन खरीदनी है', 'घर खरीदना है'].map((t) =>
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(t, style: TextStyle(fontSize: 12, color: _selectedType == t ? Colors.white : AppColors.darkGrey)),
                  selected: _selectedType == t,
                  onSelected: (_) => setState(() => _selectedType = t),
                  selectedColor: AppColors.primaryOrange,
                  backgroundColor: AppColors.lightGrey,
                ),
              )).toList()),
          ),
        ),

        // Leads list
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: filtered.length,
            itemBuilder: (_, i) {
              final lead = filtered[i];
              final purchased = lead['purchased'] as bool;
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Text(lead['icon'].toString(), style: const TextStyle(fontSize: 30)),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.primaryOrange.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6)),
                          child: Text(lead['type'].toString(),
                            style: const TextStyle(color: AppColors.primaryOrange, fontSize: 11, fontWeight: FontWeight.w600))),
                        const SizedBox(height: 4),
                        Text(lead['title'].toString(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      ])),
                      if (purchased)
                        const Icon(Icons.check_circle, color: AppColors.success, size: 24),
                    ]),
                    const SizedBox(height: 8),
                    Text(lead['desc'].toString(), style: const TextStyle(color: AppColors.darkGrey, fontSize: 13)),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Icon(Icons.location_on, size: 13, color: AppColors.grey),
                      Text(lead['location'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                      const Spacer(),
                      Text(lead['budget'].toString(), style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold, fontSize: 13)),
                    ]),
                    const SizedBox(height: 10),
                    purchased
                      ? Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: AppColors.success.withOpacity(0.08), borderRadius: BorderRadius.circular(10)),
                          child: Row(children: [
                            const Icon(Icons.person, color: AppColors.success, size: 18),
                            const SizedBox(width: 8),
                            Expanded(child: Text('Contact: ${lead['postedBy']}\n📞 98XXXXXXXX', style: const TextStyle(color: AppColors.success, fontSize: 13))),
                          ]))
                      : SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              if (!auth.isVerified) { VerifyPopup.show(context); return; }
                              _confirmBuyLead(context, lead);
                            },
                            icon: const Icon(Icons.lock_open, size: 16),
                            label: const Text('₹2 में Lead खरीदें'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primaryOrange,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                          ),
                        ),
                  ]),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }

  void _confirmBuyLead(BuildContext context, Map<String, dynamic> lead) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Lead खरीदें?'),
        content: Text('${lead['title']}\n\nकीमत: ₹2\n\nContact details unlock होंगे।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => lead['purchased'] = true);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Lead खरीदी गई! Contact देखें।'), backgroundColor: AppColors.success));
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange),
            child: const Text('₹2 Pay करें')),
        ],
      ),
    );
  }
}
