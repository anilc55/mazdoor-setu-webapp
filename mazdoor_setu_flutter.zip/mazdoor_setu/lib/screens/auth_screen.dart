import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  int _step = 0; // 0=phone, 1=otp, 2=name+role, 3=location

  final _phoneController = TextEditingController();
  final _nameController = TextEditingController();
  String _otp = '';
  UserRole _selectedRole = UserRole.worker;
  bool _isSending = false;
  bool _isVerifying = false;
  String _cityInput = '';
  int _resendSeconds = 30;
  bool _canResend = false;

  @override
  void dispose() {
    _phoneController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  void _startResendTimer() {
    setState(() {
      _resendSeconds = 30;
      _canResend = false;
    });
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() => _resendSeconds--);
      if (_resendSeconds <= 0) {
        setState(() => _canResend = true);
        return false;
      }
      return true;
    });
  }

  Future<void> _sendOtp() async {
    if (_phoneController.text.length != 10) {
      _showSnack('सही 10 अंकों का नंबर डालें');
      return;
    }
    setState(() => _isSending = true);
    await Future.delayed(const Duration(seconds: 1));
    if (!mounted) return;
    context.read<AppProvider>().sendOtp(_phoneController.text);
    setState(() {
      _isSending = false;
      _step = 1;
    });
    _startResendTimer();
  }

  Future<void> _verifyOtp() async {
    if (_otp.length != 6) {
      _showSnack('6 अंकों का OTP डालें');
      return;
    }
    setState(() => _isVerifying = true);
    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted) return;
    context.read<AppProvider>().verifyOtp(_otp, _phoneController.text);
    setState(() {
      _isVerifying = false;
      _step = 2;
    });
  }

  void _saveProfile() {
    if (_nameController.text.trim().isEmpty) {
      _showSnack('कृपया अपना नाम भरें');
      return;
    }
    context.read<AppProvider>().setUserName(_nameController.text.trim());
    context.read<AppProvider>().setUserRole(_selectedRole);
    setState(() => _step = 3);
  }

  void _saveLocation() {
    if (_cityInput.trim().isEmpty) {
      _showSnack('कृपया शहर का नाम भरें');
      return;
    }
    context.read<AppProvider>().setUserLocation(_cityInput.trim(), '', null, null);
    Navigator.pushReplacementNamed(context, '/kyc');
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppColors.primaryGreen),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.center,
            colors: [AppColors.primaryGreen, AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Top header
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                child: Row(
                  children: [
                    if (_step > 0)
                      GestureDetector(
                        onTap: () => setState(() => _step--),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.arrow_back_ios_new,
                              color: Colors.white, size: 18),
                        ),
                      ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'मज़दूर सेतु',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          _stepSubtitle(),
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 13),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Progress indicator
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: List.generate(4, (i) {
                    return Expanded(
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        height: 4,
                        decoration: BoxDecoration(
                          color: i <= _step
                              ? AppColors.accentOrange
                              : Colors.white30,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    );
                  }),
                ),
              ),

              const SizedBox(height: 24),

              // Content card
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: AppColors.background,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(30)),
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: _buildStep(),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _stepSubtitle() {
    switch (_step) {
      case 0: return 'Login / Register करें';
      case 1: return 'OTP Verify करें';
      case 2: return 'Profile बनाएं';
      case 3: return 'Location बताएं';
      default: return '';
    }
  }

  Widget _buildStep() {
    switch (_step) {
      case 0: return _buildPhoneStep();
      case 1: return _buildOtpStep();
      case 2: return _buildProfileStep();
      case 3: return _buildLocationStep();
      default: return const SizedBox();
    }
  }

  Widget _buildPhoneStep() {
    return Column(
      key: const ValueKey('phone'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('📱 मोबाइल नंबर',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text(
          'आपके नंबर पर OTP भेजा जाएगा',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        const SizedBox(height: 32),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10)
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                decoration: const BoxDecoration(
                  border: Border(
                      right: BorderSide(color: AppColors.lightGrey)),
                ),
                child: const Text('+91',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              Expanded(
                child: TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    hintText: 'मोबाइल नंबर डालें',
                    border: InputBorder.none,
                    filled: false,
                    counterText: '',
                    contentPadding: EdgeInsets.symmetric(horizontal: 16),
                  ),
                  style: const TextStyle(fontSize: 18, letterSpacing: 2),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 40),
        ElevatedButton(
          onPressed: _isSending ? null : _sendOtp,
          child: _isSending
              ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2.5),
                )
              : const Text('OTP भेजें'),
        ),
        const SizedBox(height: 24),
        const Center(
          child: Text(
            '📱 Free registration • Secure & Safe',
            style: TextStyle(color: AppColors.grey, fontSize: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildOtpStep() {
    return Column(
      key: const ValueKey('otp'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('🔐 OTP Verify करें',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(
          '+91 ${_phoneController.text} पर OTP भेजा गया',
          style: const TextStyle(color: AppColors.textSecondary),
        ),
        const SizedBox(height: 32),
        PinCodeTextField(
          appContext: context,
          length: 6,
          onChanged: (v) => _otp = v,
          onCompleted: (v) {
            _otp = v;
            _verifyOtp();
          },
          pinTheme: PinTheme(
            shape: PinCodeFieldShape.box,
            borderRadius: BorderRadius.circular(12),
            fieldHeight: 55,
            fieldWidth: 48,
            activeFillColor: Colors.white,
            inactiveFillColor: Colors.white,
            selectedFillColor: Colors.white,
            activeColor: AppColors.primaryGreen,
            inactiveColor: AppColors.lightGrey,
            selectedColor: AppColors.primaryGreen,
          ),
          enableActiveFill: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          animationType: AnimationType.fade,
        ),
        const SizedBox(height: 16),
        Center(
          child: _canResend
              ? TextButton(
                  onPressed: () {
                    _sendOtp();
                    _startResendTimer();
                  },
                  child: const Text('OTP फिर से भेजें',
                      style: TextStyle(color: AppColors.primaryGreen)),
                )
              : Text(
                  '${_resendSeconds}s में दोबारा भेजें',
                  style: const TextStyle(color: AppColors.grey),
                ),
        ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _isVerifying ? null : _verifyOtp,
          child: _isVerifying
              ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2.5),
                )
              : const Text('Verify करें'),
        ),
        const SizedBox(height: 16),
        const Center(
          child: Text(
            '💡 Demo के लिए: कोई भी 6 अंक डालें',
            style: TextStyle(color: AppColors.grey, fontSize: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileStep() {
    return Column(
      key: const ValueKey('profile'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('👤 Profile बनाएं',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('आप कौन हैं? Role चुनें',
            style: TextStyle(color: AppColors.textSecondary)),
        const SizedBox(height: 24),

        // Name field
        TextField(
          controller: _nameController,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'पूरा नाम (Full Name)',
            prefixIcon: Icon(Icons.person_outline),
          ),
        ),
        const SizedBox(height: 24),

        // Role selection
        const Text('अपना Role चुनें:',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.4,
          children: UserRole.values.map((role) {
            final isSelected = _selectedRole == role;
            return _RoleCard(
              role: role,
              isSelected: isSelected,
              onTap: () => setState(() => _selectedRole = role),
            );
          }).toList(),
        ),
        const SizedBox(height: 32),
        ElevatedButton(
          onPressed: _saveProfile,
          child: const Text('आगे बढ़ें'),
        ),
      ],
    );
  }

  Widget _buildLocationStep() {
    return Column(
      key: const ValueKey('location'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('📍 Location बताएं',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text(
          'Nearby workers और rooms दिखाने के लिए जरूरी है',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        const SizedBox(height: 32),

        // GPS button
        GestureDetector(
          onTap: () async {
            // In real app: use geolocator
            setState(() => _cityInput = 'Delhi');
            _showSnack('📍 Location मिल गई: Delhi');
          },
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.primaryGreen.withOpacity(0.1),
                  AppColors.primaryGreen.withOpacity(0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: AppColors.primaryGreen.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.primaryGreen,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.gps_fixed,
                      color: Colors.white, size: 26),
                ),
                const SizedBox(width: 16),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('GPS से Location लें',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          )),
                      SizedBox(height: 2),
                      Text('Automatic detect करें',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 12,
                          )),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios,
                    size: 16, color: AppColors.grey),
              ],
            ),
          ),
        ),

        const SizedBox(height: 20),
        const Row(
          children: [
            Expanded(child: Divider()),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Text('या', style: TextStyle(color: AppColors.grey)),
            ),
            Expanded(child: Divider()),
          ],
        ),
        const SizedBox(height: 20),

        TextField(
          onChanged: (v) => _cityInput = v,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(
            labelText: 'शहर का नाम टाइप करें',
            hintText: 'जैसे: Delhi, Mumbai, Noida...',
            prefixIcon: const Icon(Icons.location_city),
            suffixText: _cityInput.isNotEmpty ? _cityInput : null,
          ),
        ),

        const SizedBox(height: 36),
        ElevatedButton(
          onPressed: _saveLocation,
          child: const Text('शुरू करें 🚀'),
        ),
      ],
    );
  }
}

// ─── Role Selection Card ─────────────────────
class _RoleCard extends StatelessWidget {
  final UserRole role;
  final bool isSelected;
  final VoidCallback onTap;

  const _RoleCard({
    required this.role,
    required this.isSelected,
    required this.onTap,
  });

  Color get _color {
    switch (role) {
      case UserRole.worker:    return AppColors.workerColor;
      case UserRole.thekedar:  return AppColors.thekedarColor;
      case UserRole.company:   return AppColors.companyColor;
      case UserRole.roomOwner: return AppColors.roomOwnerColor;
    }
  }

  String get _emoji {
    switch (role) {
      case UserRole.worker:    return '👷';
      case UserRole.thekedar:  return '🏗️';
      case UserRole.company:   return '🏢';
      case UserRole.roomOwner: return '🏠';
    }
  }

  String get _label {
    switch (role) {
      case UserRole.worker:    return 'मजदूर\nWorker';
      case UserRole.thekedar:  return 'ठेकेदार\nContractor';
      case UserRole.company:   return 'कंपनी\nCompany';
      case UserRole.roomOwner: return 'रूम मालिक\nRoom Owner';
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: isSelected ? _color.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? _color : AppColors.lightGrey,
            width: isSelected ? 2 : 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: _color.withOpacity(0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  )
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_emoji, style: const TextStyle(fontSize: 30)),
            const SizedBox(height: 6),
            Text(
              _label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                fontWeight:
                    isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? _color : AppColors.textPrimary,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
