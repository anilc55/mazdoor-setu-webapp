import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../models/room_model.dart';
import '../widgets/common_widgets.dart';

class AddRoomScreen extends StatefulWidget {
  const AddRoomScreen({super.key});
  @override
  State<AddRoomScreen> createState() => _AddRoomScreenState();
}

class _AddRoomScreenState extends State<AddRoomScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _rentCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  String _roomType = 'Single';
  final List<String> _selectedFacilities = [];
  final List<String> _photos = [];
  bool _isPublic = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _titleCtrl.dispose(); _descCtrl.dispose();
    _rentCtrl.dispose(); _locationCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    // In real: ImagePicker().pickImage(source: ImageSource.gallery)
    setState(() => _photos.add('photo_${_photos.length + 1}.jpg'));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Photo added ✓'), backgroundColor: AppColors.success));
  }

  Future<void> _submitRoom(bool isPublic) async {
    if (!_formKey.currentState!.validate()) return;
    setState(() { _isLoading = true; _isPublic = isPublic; });
    await Future.delayed(const Duration(seconds: 1)); // Firestore save
    setState(() => _isLoading = false);
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.check_circle, color: AppColors.success, size: 60),
          const SizedBox(height: 12),
          Text(isPublic ? 'रूम Publish हो गया!' : 'रूम Save हो गया!',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(isPublic
            ? '10 दिन Free listing। सभी users देख सकेंगे।'
            : 'Draft में save हुआ। बाद में Publish कर सकते हैं।',
            style: const TextStyle(color: AppColors.grey, fontSize: 13), textAlign: TextAlign.center),
        ]),
        actions: [
          TextButton(
            onPressed: () { Navigator.pop(context); Navigator.pop(context); },
            child: const Text('OK', style: TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(title: const Text('रूम Add करें'), backgroundColor: AppColors.primaryGreen),
      body: LoadingOverlay(
        isLoading: _isLoading,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Pricing info card
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.primaryOrange.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3))),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('💡 Listing Price', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryOrange)),
                  SizedBox(height: 6),
                  Text('• पहली Post → FREE (10 दिन)\n• ₹10 = 10 दिन\n• ₹20 = 30 दिन',
                    style: TextStyle(fontSize: 13, color: AppColors.darkGrey, height: 1.6)),
                ]),
              ),
              const SizedBox(height: 20),

              const Text('रूम की जानकारी', style: AppTextStyles.heading3),
              const SizedBox(height: 12),

              TextFormField(
                controller: _titleCtrl,
                decoration: const InputDecoration(labelText: 'Title *', hintText: 'जैसे: सिंगल रूम, Clean & Neat'),
                validator: (v) => v?.isEmpty == true ? 'Title डालें' : null,
              ),
              const SizedBox(height: 14),

              TextFormField(
                controller: _rentCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(labelText: 'किराया (₹/माह) *', prefixText: '₹ '),
                validator: (v) => v?.isEmpty == true ? 'किराया डालें' : null,
              ),
              const SizedBox(height: 14),

              TextFormField(
                controller: _locationCtrl,
                decoration: const InputDecoration(
                  labelText: 'Location *',
                  hintText: 'Area, City',
                  suffixIcon: Icon(Icons.my_location, color: AppColors.primaryGreen)),
                validator: (v) => v?.isEmpty == true ? 'Location डालें' : null,
              ),
              const SizedBox(height: 14),

              // Room Type
              const Text('रूम Type:', style: AppTextStyles.label),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: ['Single', 'Shared', 'PG', 'Family'].map((t) =>
                ChoiceChip(
                  label: Text(t),
                  selected: _roomType == t,
                  onSelected: (_) => setState(() => _roomType = t),
                  selectedColor: AppColors.primaryGreen,
                  labelStyle: TextStyle(color: _roomType == t ? Colors.white : AppColors.black),
                )).toList()),
              const SizedBox(height: 14),

              TextFormField(
                controller: _descCtrl,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Description', hintText: 'रूम के बारे में बताएं...'),
              ),
              const SizedBox(height: 20),

              const Text('Facilities:', style: AppTextStyles.heading3),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: RoomFacilities.all.map((f) {
                final selected = _selectedFacilities.contains(f);
                return FilterChip(
                  label: Text(f, style: TextStyle(fontSize: 12, color: selected ? Colors.white : AppColors.darkGrey)),
                  selected: selected,
                  onSelected: (_) => setState(() {
                    selected ? _selectedFacilities.remove(f) : _selectedFacilities.add(f);
                  }),
                  selectedColor: AppColors.primaryGreen,
                  backgroundColor: AppColors.lightGrey,
                  checkmarkColor: Colors.white,
                );
              }).toList()),
              const SizedBox(height: 20),

              // Photos
              const Text('Photos:', style: AppTextStyles.heading3),
              const SizedBox(height: 8),
              SizedBox(
                height: 90,
                child: ListView(scrollDirection: Axis.horizontal, children: [
                  ..._photos.map((p) => Container(
                    width: 80, height: 80, margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(color: AppColors.lightGrey, borderRadius: BorderRadius.circular(10),
                      image: const DecorationImage(image: AssetImage('assets/images/logo.png'), fit: BoxFit.cover)),
                    child: Align(alignment: Alignment.topRight,
                      child: GestureDetector(
                        onTap: () => setState(() => _photos.remove(p)),
                        child: Container(margin: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(color: AppColors.error, shape: BoxShape.circle),
                          child: const Icon(Icons.close, color: Colors.white, size: 14)))))),
                  GestureDetector(
                    onTap: _pickPhoto,
                    child: Container(
                      width: 80, height: 80,
                      decoration: BoxDecoration(
                        color: AppColors.primaryGreen.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.primaryGreen, style: BorderStyle.solid)),
                      child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.add_photo_alternate, color: AppColors.primaryGreen, size: 28),
                        Text('Add Photo', style: TextStyle(fontSize: 10, color: AppColors.primaryGreen)),
                      ]))),
                ]),
              ),
              const SizedBox(height: 30),

              // Save buttons
              Row(children: [
                Expanded(child: OutlinedButton.icon(
                  onPressed: () => _submitRoom(false),
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('Save (Private)'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primaryGreen,
                    side: const BorderSide(color: AppColors.primaryGreen),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                )),
                const SizedBox(width: 12),
                Expanded(child: ElevatedButton.icon(
                  onPressed: () => _submitRoom(true),
                  icon: const Icon(Icons.public),
                  label: const Text('Publish'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                )),
              ]),
              const SizedBox(height: 20),
            ]),
          ),
        ),
      ),
    );
  }
}
