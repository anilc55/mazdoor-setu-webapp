import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class RoomDetailScreen extends StatelessWidget {
  const RoomDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final room = ModalRoute.of(context)?.settings.arguments as Map? ?? {};
    final auth = context.watch<AuthProvider>();
    final facilities = room['facilities'] as List? ?? [];

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 240,
          pinned: true,
          backgroundColor: AppColors.primaryGreen,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.primaryGreen, Color(0xFF81C784)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight)),
              child: const Center(child: Icon(Icons.home, size: 100, color: Colors.white54)),
            ),
          ),
          title: Text(room['title']?.toString() ?? 'Room Details'),
        ),
        SliverList(delegate: SliverChildListDelegate([
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(room['title']?.toString() ?? '',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                    Text('₹${room['rent']}/माह', style: const TextStyle(fontSize: 18, color: AppColors.primaryOrange, fontWeight: FontWeight.bold)),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    const Icon(Icons.location_on, size: 16, color: AppColors.grey),
                    const SizedBox(width: 4),
                    Text(room['location']?.toString() ?? '', style: const TextStyle(color: AppColors.grey)),
                  ]),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: AppColors.primaryGreen.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                    child: Text(room['type']?.toString() ?? '', style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.w600))),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Facilities
          if (facilities.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Facilities:', style: AppTextStyles.heading3),
                    const SizedBox(height: 10),
                    Wrap(spacing: 8, runSpacing: 8, children: facilities.map((f) =>
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: AppColors.primaryGreen.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.primaryGreen.withOpacity(0.3))),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.check_circle, color: AppColors.primaryGreen, size: 14),
                          const SizedBox(width: 4),
                          Text(f.toString(), style: const TextStyle(fontSize: 13, color: AppColors.primaryGreen)),
                        ]))).toList()),
                  ]),
                ),
              ),
            ),
          const SizedBox(height: 12),

          // Owner info
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  CircleAvatar(backgroundColor: AppColors.primaryGreen.withOpacity(0.1),
                    child: Text((room['owner']?.toString() ?? 'O')[0],
                      style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(room['owner']?.toString() ?? 'Owner', style: const TextStyle(fontWeight: FontWeight.bold)),
                    const Text('रूम ओनर', style: TextStyle(color: AppColors.grey, fontSize: 12)),
                  ])),
                  const Icon(Icons.verified, color: AppColors.info, size: 20),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 24),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ElevatedButton.icon(
              onPressed: () {
                if (!auth.isVerified) { VerifyPopup.show(context); return; }
                if (!auth.canMakeCall()) { Navigator.pushNamed(context, '/payment'); return; }
                auth.decrementFreeCall();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Calling ${room['owner']}...'), backgroundColor: AppColors.success));
              },
              icon: const Icon(Icons.phone, size: 20),
              label: const Text('रूम ओनर से बात करें', style: TextStyle(fontSize: 16)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                minimumSize: const Size(double.infinity, 54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            ),
          ),
          const SizedBox(height: 24),
        ])),
      ]),
    );
  }
}
