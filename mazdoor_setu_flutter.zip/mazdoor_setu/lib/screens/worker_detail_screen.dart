import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class WorkerDetailScreen extends StatelessWidget {
  const WorkerDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final worker = ModalRoute.of(context)?.settings.arguments as Map? ?? {};
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 220,
          pinned: true,
          backgroundColor: AppColors.primaryGreen,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.darkGreen, AppColors.primaryGreen],
                  begin: Alignment.topLeft, end: Alignment.bottomRight)),
              child: SafeArea(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const SizedBox(height: 40),
                CircleAvatar(radius: 44, backgroundColor: Colors.white,
                  child: Text(worker['name']?.toString()[0] ?? 'W',
                    style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: AppColors.primaryGreen))),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(worker['name']?.toString() ?? 'Worker', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  if (worker['verified'] == true) ...[
                    const SizedBox(width: 6),
                    const Icon(Icons.verified, color: Colors.lightBlueAccent, size: 18)],
                ]),
                const SizedBox(height: 4),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.location_on, color: Colors.white60, size: 14),
                  Text(worker['location']?.toString() ?? '', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                ]),
              ])),
            ),
          ),
        ),
        SliverList(delegate: SliverChildListDelegate([
          const SizedBox(height: 16),
          // Stats row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              _infoBox('⭐ Rating', worker['rating']?.toString() ?? '—', Colors.amber),
              const SizedBox(width: 10),
              _infoBox('🔨 Experience', worker['experience']?.toString() ?? '—', AppColors.primaryGreen),
              const SizedBox(width: 10),
              _infoBox('✅ Status', worker['available'] == true ? 'Available' : 'Busy',
                worker['available'] == true ? AppColors.success : AppColors.grey),
            ]),
          ),
          const SizedBox(height: 16),

          // Skills
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Skills:', style: AppTextStyles.heading3),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 6, children: ((worker['skills'] as List?) ?? ['मजदूर']).map((s) =>
                SkillChip(skill: s.toString(), isSelected: true)).toList()),
            ]),
          ),
          const SizedBox(height: 20),

          // About
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('About:', style: AppTextStyles.heading3),
              const SizedBox(height: 8),
              const Text('मेहनती और विश्वसनीय कारीगर। समय पर काम पूरा करना मेरी पहचान है। किसी भी बड़े या छोटे प्रोजेक्ट के लिए उपलब्ध।',
                style: TextStyle(color: AppColors.darkGrey, fontSize: 14, height: 1.6)),
            ]),
          ),
          const SizedBox(height: 30),

          // Contact buttons
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(child: OutlinedButton.icon(
                onPressed: () {
                  if (!auth.isVerified) { VerifyPopup.show(context); return; }
                  if (!auth.canMakeCall()) { Navigator.pushNamed(context, '/payment'); return; }
                  auth.decrementFreeCall();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Call connecting...'), backgroundColor: AppColors.success));
                },
                icon: const Icon(Icons.phone, size: 18),
                label: const Text('Call करें'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primaryGreen,
                  side: const BorderSide(color: AppColors.primaryGreen, width: 2),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              )),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton.icon(
                onPressed: () {
                  if (!auth.isVerified) { VerifyPopup.show(context); return; }
                  Navigator.pushNamed(context, '/chat', arguments: worker);
                },
                icon: const Icon(Icons.chat, size: 18),
                label: const Text('Chat करें'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryGreen,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              )),
            ]),
          ),
          const SizedBox(height: 20),
        ])),
      ]),
    );
  }

  Widget _infoBox(String label, String value, Color color) {
    return Expanded(child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6)]),
      child: Column(children: [
        Text(label, style: const TextStyle(fontSize: 11, color: AppColors.grey)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: color)),
      ]),
    ));
  }
}
