import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';
import 'worker_listing_screen.dart';
import 'room_listing_screen.dart';
import 'chat_list_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentTab = 0;

  final List<Widget> _tabs = const [
    _HomeTab(),
    WorkerListingScreen(),
    RoomListingScreen(),
    ChatListScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentTab, children: _tabs),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (i) => setState(() => _currentTab = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'मजदूर'),
          BottomNavigationBarItem(icon: Icon(Icons.home_work), label: 'रूम'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentUser;

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            expandedHeight: 160,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [AppColors.darkGreen, AppColors.primaryGreen])),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        CircleAvatar(
                          radius: 24, backgroundColor: Colors.white,
                          child: Text(
                            (user?.name.isNotEmpty == true ? user!.name[0].toUpperCase() : 'U'),
                            style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold, fontSize: 22))),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('नमस्ते, ${user?.name ?? "User"}! 👋',
                            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                          Text(user?.roleDisplayName ?? '', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                        ])),
                        // Notification
                        IconButton(
                          icon: const Icon(Icons.notifications_outlined, color: Colors.white),
                          onPressed: () {}),
                      ]),
                      const SizedBox(height: 12),
                      // Verification status
                      if (user?.verificationStatus == VerificationStatus.notStarted)
                        GestureDetector(
                          onTap: () => Navigator.pushNamed(context, '/kyc'),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: AppColors.primaryOrange.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(8)),
                            child: const Row(children: [
                              Icon(Icons.warning, color: Colors.white, size: 16),
                              SizedBox(width: 6),
                              Text('KYC Verify करें - Tap करें', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                              Spacer(),
                              Icon(Icons.arrow_forward_ios, color: Colors.white, size: 12),
                            ]),
                          ),
                        ),
                    ]),
                  ),
                ),
              ),
            ),
            title: const Text('मजदूर सेतु'),
            backgroundColor: AppColors.primaryGreen,
          ),

          SliverList(
            delegate: SliverChildListDelegate([
              // Search Bar
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'मजदूर, ठेकेदार, रूम खोजें...',
                    prefixIcon: const Icon(Icons.search, color: AppColors.grey),
                    filled: true, fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  ),
                  readOnly: true,
                  onTap: () {},
                ),
              ),

              // Quick Actions
              const SectionHeader(title: '⚡ Quick Actions'),
              _QuickActionsGrid(),
              const SizedBox(height: 8),

              // Stats cards
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  _StatCard(label: 'Free Calls', value: '${user?.freeCallsLeft ?? 2}', icon: Icons.phone, color: AppColors.success),
                  const SizedBox(width: 12),
                  _StatCard(label: 'Free Chats', value: '${user?.freeChatsLeft ?? 3}', icon: Icons.chat, color: AppColors.info),
                  const SizedBox(width: 12),
                  _StatCard(label: 'Wallet', value: '₹${((user?.walletBalance ?? 0) / 100).toStringAsFixed(0)}', icon: Icons.account_balance_wallet, color: AppColors.primaryOrange),
                ]),
              ),
              const SizedBox(height: 20),

              // Featured Workers
              const SectionHeader(title: '🔥 आस-पास के मजदूर', actionText: 'सभी देखें'),
              _FeaturedWorkers(),
              const SizedBox(height: 20),

              // Available Rooms
              const SectionHeader(title: '🏠 उपलब्ध रूम', actionText: 'सभी देखें'),
              _FeaturedRooms(),
              const SizedBox(height: 20),

              // Leads
              const SectionHeader(title: '🎯 ताजा Leads', actionText: 'सभी देखें'),
              _FeaturedLeads(),
              const SizedBox(height: 30),
            ]),
          ),
        ],
      ),
    );
  }
}

class _QuickActionsGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final actions = [
      _Action('मजदूर खोजें', Icons.search, AppColors.workerColor, '/workers'),
      _Action('काम ढूंढें', Icons.work, AppColors.primaryGreen, '/workers'),
      _Action('रूम देखें', Icons.home, AppColors.roomOwnerColor, '/rooms'),
      _Action('Leads खरीदें', Icons.trending_up, AppColors.primaryOrange, '/leads'),
      _Action('रूम डालें', Icons.add_home, AppColors.companyColor, '/add-room'),
      _Action('Recharge करें', Icons.wallet, AppColors.thekedaarColor, '/payment'),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.count(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 3, childAspectRatio: 1.0,
        crossAxisSpacing: 10, mainAxisSpacing: 10,
        children: actions.map((a) => GestureDetector(
          onTap: () => Navigator.pushNamed(context, a.route),
          child: Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 6, offset: const Offset(0, 2))]),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(width: 44, height: 44,
                decoration: BoxDecoration(color: a.color.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
                child: Icon(a.icon, color: a.color, size: 24)),
              const SizedBox(height: 6),
              Text(a.label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: AppColors.black),
                textAlign: TextAlign.center),
            ]),
          ),
        )).toList(),
      ),
    );
  }
}

class _Action {
  final String label, route;
  final IconData icon;
  final Color color;
  const _Action(this.label, this.icon, this.color, this.route);
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6)]),
        child: Column(children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 4),
          Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
          Text(label, style: const TextStyle(fontSize: 10, color: AppColors.grey), textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}

// Demo Featured Workers
class _FeaturedWorkers extends StatelessWidget {
  final _demoWorkers = const [
    {'name': 'राम कुमार', 'skill': 'राजमिस्त्री', 'location': 'दिल्ली', 'rating': '4.8', 'available': true},
    {'name': 'शिव प्रसाद', 'skill': 'प्लंबर', 'location': 'मुंबई', 'rating': '4.5', 'available': true},
    {'name': 'मोहन लाल', 'skill': 'पेंटर', 'location': 'जयपुर', 'rating': '4.7', 'available': false},
  ];

  const _FeaturedWorkers();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 150,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _demoWorkers.length,
        itemBuilder: (_, i) {
          final w = _demoWorkers[i];
          return GestureDetector(
            onTap: () => Navigator.pushNamed(context, '/worker-detail', arguments: w),
            child: Container(
              width: 130, margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8)]),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Stack(children: [
                    CircleAvatar(radius: 28, backgroundColor: AppColors.primaryGreen.withOpacity(0.15),
                      child: Text(w['name']![0], style: const TextStyle(color: AppColors.primaryGreen, fontSize: 22, fontWeight: FontWeight.bold))),
                    if (w['available'] == true)
                      Positioned(bottom: 0, right: 0,
                        child: Container(width: 12, height: 12,
                          decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 1.5)))),
                  ]),
                  const SizedBox(height: 8),
                  Text(w['name']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13), overflow: TextOverflow.ellipsis),
                  Text(w['skill']!, style: const TextStyle(color: AppColors.grey, fontSize: 11)),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.star, color: Colors.amber, size: 12),
                    Text(' ${w['rating']}', style: const TextStyle(fontSize: 11)),
                  ]),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

// Demo Featured Rooms
class _FeaturedRooms extends StatelessWidget {
  final _demoRooms = const [
    {'title': 'सिंगल रूम', 'location': 'करोल बाग, दिल्ली', 'rent': '₹3,000/माह', 'facilities': 'पानी, बिजली, WiFi'},
    {'title': 'PG Room', 'location': 'अंधेरी, मुंबई', 'rent': '₹5,000/माह', 'facilities': 'AC, Kitchen, Bath'},
    {'title': 'शेयर्ड रूम', 'location': 'मालवीय नगर, जयपुर', 'rent': '₹2,000/माह', 'facilities': 'Fan, Electricity'},
  ];
  const _FeaturedRooms();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 155,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _demoRooms.length,
        itemBuilder: (_, i) {
          final r = _demoRooms[i];
          return GestureDetector(
            onTap: () => Navigator.pushNamed(context, '/room-detail', arguments: r),
            child: Container(
              width: 180, margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8)]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(height: 80,
                  decoration: BoxDecoration(
                    color: AppColors.primaryGreen.withOpacity(0.1),
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(14))),
                  child: const Center(child: Icon(Icons.home, size: 40, color: AppColors.primaryGreen))),
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(r['title']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    Text(r['location']!, style: const TextStyle(color: AppColors.grey, fontSize: 11), overflow: TextOverflow.ellipsis),
                    Text(r['rent']!, style: const TextStyle(color: AppColors.primaryOrange, fontWeight: FontWeight.bold, fontSize: 13)),
                  ]),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _FeaturedLeads extends StatelessWidget {
  final _demoLeads = const [
    {'type': '🧱 मजदूर चाहिए', 'desc': '5 राजमिस्त्री - 3 महीने', 'location': 'नोएडा'},
    {'type': '🏠 रूम चाहिए', 'desc': 'सिंगल रूम - ₹4000 बजट', 'location': 'दिल्ली'},
    {'type': '🌾 जमीन खरीदनी है', 'desc': '2 बीघा - खेती के लिए', 'location': 'हरियाणा'},
  ];
  const _FeaturedLeads();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(children: _demoLeads.map((l) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 6)]),
        child: Row(children: [
          Container(width: 44, height: 44,
            decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
            child: const Center(child: Text('🎯', style: TextStyle(fontSize: 24)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(l['type']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            Text(l['desc']!, style: const TextStyle(color: AppColors.grey, fontSize: 12)),
            Text('📍 ${l['location']}', style: const TextStyle(color: AppColors.grey, fontSize: 11)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: AppColors.primaryOrange, borderRadius: BorderRadius.circular(8)),
            child: const Text('₹2', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13))),
        ]),
      )).toList()),
    );
  }
}
