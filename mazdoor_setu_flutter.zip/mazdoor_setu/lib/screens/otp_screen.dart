import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});
  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final List<TextEditingController> _controllers = List.generate(6, (_) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(6, (_) => FocusNode());
  int _resendTimer = 30;
  bool _canResend = false;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() {
        if (_resendTimer > 0) { _resendTimer--; }
        else { _canResend = true; }
      });
      return _resendTimer > 0;
    });
  }

  String get _otp => _controllers.map((c) => c.text).join();

  Future<void> _verifyOTP() async {
    if (_otp.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('6 अंकों का OTP दर्ज करें'), backgroundColor: AppColors.error));
      return;
    }
    final phone = ModalRoute.of(context)!.settings.arguments as String;
    final auth = context.read<AuthProvider>();
    final success = await auth.verifyOTP(_otp, phone);
    if (success && mounted) {
      // Check if new user (no name set yet)
      if (auth.currentUser?.name.isEmpty ?? true) {
        Navigator.pushReplacementNamed(context, '/role-selection');
      } else {
        Navigator.pushReplacementNamed(context, '/home');
      }
    } else if (mounted && auth.errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(auth.errorMessage!), backgroundColor: AppColors.error));
    }
  }

  @override
  void dispose() {
    for (var c in _controllers) c.dispose();
    for (var f in _focusNodes) f.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final phone = ModalRoute.of(context)?.settings.arguments as String? ?? '';
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(title: const Text('OTP Verification'), backgroundColor: AppColors.primaryGreen),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          const SizedBox(height: 30),
          Container(
            width: 90, height: 90,
            decoration: const BoxDecoration(color: AppColors.primaryGreen, shape: BoxShape.circle),
            child: const Icon(Icons.sms, color: Colors.white, size: 44),
          ),
          const SizedBox(height: 20),
          const Text('OTP दर्ज करें', style: AppTextStyles.heading2),
          const SizedBox(height: 8),
          Text('+91 $phone पर OTP भेजा गया है',
            style: const TextStyle(color: AppColors.grey, fontSize: 14), textAlign: TextAlign.center),
          const SizedBox(height: 40),

          // OTP Fields
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(6, (i) => SizedBox(
              width: 48, height: 56,
              child: TextFormField(
                controller: _controllers[i],
                focusNode: _focusNodes[i],
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                maxLength: 1,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primaryGreen),
                decoration: InputDecoration(
                  counterText: '',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.lightGrey, width: 2)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.primaryGreen, width: 2)),
                  filled: true, fillColor: Colors.white,
                ),
                onChanged: (v) {
                  if (v.isNotEmpty && i < 5) {
                    _focusNodes[i + 1].requestFocus();
                  } else if (v.isEmpty && i > 0) {
                    _focusNodes[i - 1].requestFocus();
                  }
                  if (_otp.length == 6) _verifyOTP();
                },
              ),
            )),
          ),
          const SizedBox(height: 36),
          GreenButton(text: 'Verify करें', isLoading: auth.isLoading, onPressed: _verifyOTP),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('OTP नहीं आया? ', style: TextStyle(color: AppColors.grey)),
            _canResend
              ? TextButton(
                  onPressed: () {
                    setState(() { _resendTimer = 30; _canResend = false; });
                    _startTimer();
                    context.read<AuthProvider>().sendOTP(phone);
                  },
                  child: const Text('Resend करें', style: TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold)))
              : Text('Resend ($_resendTimer sec)', style: const TextStyle(color: AppColors.grey)),
          ]),
        ]),
      ),
    );
  }
}
