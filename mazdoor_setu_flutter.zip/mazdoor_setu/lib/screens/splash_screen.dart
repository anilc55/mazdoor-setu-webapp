import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _textController;
  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<Offset> _textSlide;
  late Animation<double> _textOpacity;

  @override
  void initState() {
    super.initState();
    _logoController = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _textController = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _logoScale = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.elasticOut));
    _logoOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.easeIn));
    _textSlide = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero)
        .animate(CurvedAnimation(parent: _textController, curve: Curves.easeOut));
    _textOpacity = Tween<double>(begin: 0, end: 1).animate(_textController);
    _logoController.forward();
    Future.delayed(const Duration(milliseconds: 500), () => _textController.forward());
    Future.delayed(const Duration(milliseconds: 3000), () {
      if (mounted) Navigator.pushReplacementNamed(context, '/privacy');
    });
  }

  @override
  void dispose() {
    _logoController.dispose();
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.darkGreen, AppColors.primaryGreen, Color(0xFF43A047)],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedBuilder(
                animation: _logoController,
                builder: (_, __) => Opacity(
                  opacity: _logoOpacity.value,
                  child: Transform.scale(
                    scale: _logoScale.value,
                    child: Container(
                      width: 150, height: 150,
                      decoration: BoxDecoration(
                        color: Colors.white, shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Image.asset('assets/images/logo.png', fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const Icon(Icons.construction, size: 80, color: AppColors.primaryGreen)),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 32),
              SlideTransition(
                position: _textSlide,
                child: FadeTransition(
                  opacity: _textOpacity,
                  child: Column(children: [
                    RichText(text: const TextSpan(children: [
                      TextSpan(text: 'मजदूर ', style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1)),
                      TextSpan(text: 'सेतु', style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: AppColors.primaryOrange, letterSpacing: 1)),
                    ])),
                    const SizedBox(height: 10),
                    const Text('काम की तलाश नहीं, समाधान का रास्ता',
                      style: TextStyle(color: Colors.white70, fontSize: 14, fontStyle: FontStyle.italic)),
                    const SizedBox(height: 50),
                    const SizedBox(width: 36, height: 36,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3)),
                  ]),
                ),
              ),
              const SizedBox(height: 60),
              FadeTransition(opacity: _textOpacity,
                child: const Text('Version 1.0.0', style: TextStyle(color: Colors.white38, fontSize: 12))),
            ],
          ),
        ),
      ),
    );
  }
}
