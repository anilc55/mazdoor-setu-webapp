import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';

class WorkerListScreen extends StatefulWidget {
  const WorkerListScreen({super.key});

  @override
  State<WorkerListScreen> createState() => _WorkerListScreenState();
}

class _WorkerListScreenState extends State<WorkerListScreen> {
  final _searchController = TextEditingController();
  WorkSkill? _selectedSkill;
  bool _onlyAvailable = false;
  bool _onlyOnline = false;
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final workers = provider.searchWorkers(
      query: _searchQuery,
      skill: _selectedSkill,
      onlyAvailable: _onlyAvailable,
      onlyOnline: _onlyOnline,
    );

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('👷 मजदूर खोजें'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: _showFilterSheet,
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            color: AppColors.primaryGreen,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: TextField(
              controller: _searchController,
              onChanged: (v) => setState(() => _searchQuery = v),
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'नाम, शहर या काम खोजें...',
                hintStyle: const TextStyle(color: Colors.white60),
                prefixIcon:
                    const Icon(Icons.search, color: Colors.white70),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear,
                            color: Colors.white70),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.white.withOpacity(0.2),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),

          // Active filters
          if (_selectedSkill != null || _onlyAvailable || _onlyOnline)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: AppColors.white,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    if (_selectedSkill != null)
                      _FilterChip(
                        label:
                            '${_selectedSkill!.emoji} ${_selectedSkill!.label}',
                        onRemove: () =>
                            setState(() => _selectedSkill = null),
                      ),
                    if (_onlyAvailable)
                      _FilterChip(
                        label: '✅ Available',
                        onRemove: () =>
                            setState(() => _onlyAvailable = false),
                      ),
                    if (_onlyOnline)
                      _FilterChip(
                        label: '🟢 Online',
                        onRemove: () =>
                            setState(() => _onlyOnline = false),
                      ),
                  ],
                ),
              ),
            ),

          // Results count
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            alignment: Alignment.centerLeft,
            child: Text(
              '${workers.length} मजदूर मिले',
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: AppColors.textSecondary,
                fontSize: 13,
              ),
            ),
          ),

          // Worker list
          Expanded(
            child: workers.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: workers.length,
                    itemBuilder: (ctx, i) =>
                        _WorkerCard(worker: workers[i]),
                  ),
          ),
        ],
      ),
    );
  }

  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _FilterSheet(
        selectedSkill: _selectedSkill,
        onlyAvailable: _onlyAvailable,
        onlyOnline: _onlyOnline,
        onApply: (skill, avail, online) {
          setState(() {
            _selectedSkill = skill;
            _onlyAvailable = avail;
            _onlyOnline = online;
          });
          Navigator.pop(context);
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('😔', style: TextStyle(fontSize: 60)),
          const SizedBox(height: 16),
          const Text('कोई मजदूर नहीं मिला',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Filter बदलें या दूसरी जगह खोजें',
              style: TextStyle(color: AppColors.textSecondary)),
          const SizedBox(height: 24),
          TextButton.icon(
            onPressed: () => setState(() {
              _searchController.clear();
              _searchQuery = '';
              _selectedSkill = null;
              _onlyAvailable = false;
              _onlyOnline = false;
            }),
            icon: const Icon(Icons.refresh),
            label: const Text('Reset करें'),
          ),
        ],
      ),
    );
  }
}

// ─── Worker Card ─────────────────────────────
class _WorkerCard extends StatelessWidget {
  final AppUser worker;
  const _WorkerCard({required this.worker});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // Avatar
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor:
                          AppColors.primaryGreen.withOpacity(0.12),
                      child: Text(
                        worker.name.isNotEmpty
                            ? worker.name[0].toUpperCase()
                            : '?',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primaryGreen,
                        ),
                      ),
                    ),
                    if (worker.isOnline)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                            color: AppColors.success,
                            shape: BoxShape.circle,
                            border:
                                Border.all(color: Colors.white, width: 2),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 12),

                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              worker.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 6),
                          if (worker.isVerified)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.success.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.verified,
                                      size: 11,
                                      color: AppColors.success),
                                  SizedBox(width: 2),
                                  Text('Verified',
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: AppColors.success,
                                        fontWeight: FontWeight.bold,
                                      )),
                                ],
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '📍 ${worker.city ?? "Unknown"}, ${worker.state ?? ""}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(
                              color: worker.isOnline
                                  ? AppColors.success.withOpacity(0.1)
                                  : AppColors.grey.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              worker.isOnline
                                  ? '🟢 Online'
                                  : '⚫ Offline',
                              style: TextStyle(
                                fontSize: 10,
                                color: worker.isOnline
                                    ? AppColors.success
                                    : AppColors.grey,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          if (worker.isAvailableForWork)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.primaryGreen
                                    .withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                '✅ Available',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: AppColors.primaryGreen,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // Skills
            if (worker.skills.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: worker.skills.map((skill) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.primaryGreen.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: AppColors.primaryGreen.withOpacity(0.2)),
                    ),
                    child: Text(
                      '${skill.emoji} ${skill.label}',
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.primaryGreen,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],

            // Action buttons
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _handleCall(context),
                    icon: const Icon(Icons.call_outlined, size: 16),
                    label: const Text('Call करें'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryGreen,
                      side: const BorderSide(
                          color: AppColors.primaryGreen),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      minimumSize: Size.zero,
                      textStyle: const TextStyle(fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _handleChat(context),
                    icon: const Icon(Icons.chat_bubble_outline, size: 16),
                    label: const Text('Chat करें'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accentOrange,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      minimumSize: Size.zero,
                      textStyle: const TextStyle(fontSize: 13),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _handleCall(BuildContext context) {
    final provider = context.read<AppProvider>();
    final user = provider.currentUser;
    if (user == null) return;
    if (!user.isVerified) {
      _showKycDialog(context);
      return;
    }
    if (!provider.canMakeCall()) {
      _showLimitDialog(context, 'Call');
      return;
    }
    provider.useCall();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('📞 ${worker.phone} पर call...'),
        backgroundColor: AppColors.primaryGreen,
      ),
    );
  }

  void _handleChat(BuildContext context) {
    final provider = context.read<AppProvider>();
    final user = provider.currentUser;
    if (user == null) return;
    if (!user.isVerified) {
      _showKycDialog(context);
      return;
    }
    provider.startConversation(worker);
    Navigator.pushNamed(context, '/chat');
  }

  void _showKycDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('⚠️ पहले Verify करें'),
        content: const Text(
            'Call और Chat करने के लिए KYC Verify करना जरूरी है।'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('बाद में')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/kyc');
            },
            child: const Text('KYC करें'),
          ),
        ],
      ),
    );
  }

  void _showLimitDialog(BuildContext context, String type) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('$type Limit खत्म'),
        content: const Text('Plan upgrade करें या recharge करें।'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('बाद में')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/profile');
            },
            child: const Text('Recharge'),
          ),
        ],
      ),
    );
  }
}

// ─── Filter Sheet ─────────────────────────────
class _FilterSheet extends StatefulWidget {
  final WorkSkill? selectedSkill;
  final bool onlyAvailable;
  final bool onlyOnline;
  final Function(WorkSkill?, bool, bool) onApply;

  const _FilterSheet({
    required this.selectedSkill,
    required this.onlyAvailable,
    required this.onlyOnline,
    required this.onApply,
  });

  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  WorkSkill? _skill;
  late bool _available;
  late bool _online;

  @override
  void initState() {
    super.initState();
    _skill = widget.selectedSkill;
    _available = widget.onlyAvailable;
    _online = widget.onlyOnline;
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (_, scrollCtrl) => Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                const Text('Filter',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    setState(() {
                      _skill = null;
                      _available = false;
                      _online = false;
                    });
                  },
                  child: const Text('Reset'),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              controller: scrollCtrl,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                // Availability toggles
                const Text('Availability',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _ToggleChip(
                        label: '✅ Available Only',
                        isSelected: _available,
                        onTap: () =>
                            setState(() => _available = !_available),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ToggleChip(
                        label: '🟢 Online Only',
                        isSelected: _online,
                        onTap: () => setState(() => _online = !_online),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Skill filter
                const Text('Skill के अनुसार',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: WorkSkill.values.map((skill) {
                    final isSelected = _skill == skill;
                    return GestureDetector(
                      onTap: () => setState(() =>
                          _skill = isSelected ? null : skill),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.primaryGreen
                              : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isSelected
                                ? AppColors.primaryGreen
                                : AppColors.lightGrey,
                          ),
                        ),
                        child: Text(
                          '${skill.emoji} ${skill.label}',
                          style: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : AppColors.textPrimary,
                            fontSize: 12,
                            fontWeight: isSelected
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 32),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: ElevatedButton(
              onPressed: () => widget.onApply(_skill, _available, _online),
              child: const Text('Filter लगाएं'),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final VoidCallback onRemove;
  const _FilterChip({required this.label, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.primaryGreen.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primaryGreen.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style: const TextStyle(
                  color: AppColors.primaryGreen,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onRemove,
            child: const Icon(Icons.close,
                size: 14, color: AppColors.primaryGreen),
          ),
        ],
      ),
    );
  }
}

class _ToggleChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  const _ToggleChip(
      {required this.label,
      required this.isSelected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primaryGreen : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppColors.primaryGreen
                : AppColors.lightGrey,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isSelected ? Colors.white : AppColors.textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}
