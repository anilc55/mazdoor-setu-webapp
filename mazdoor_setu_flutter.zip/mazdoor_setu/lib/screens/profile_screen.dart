import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isAvailable = false;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentUser;

    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: CustomScrollView(slivers: [
        // Profile Header
        SliverAppBar(
          expandedHeight: 200,
          pinned: true,
          backgroundColor: AppColors.primaryGreen,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.darkGreen, AppColors.primaryGreen],
                  begin: Alignment.topLeft, end: Alignment.bottomRight)),
              child: SafeArea(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Stack(alignment: Alignment.bottomRight, children: [
                    CircleAvatar(radius: 44, backgroundColor: Colors.white,
                      child: Text(user?.name.isNotEmpty == true ? user!.name[0].toUpperCase() : 'U',
                        style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold, color: AppColors.primaryGreen))),
                    Container(
                      width: 28, height: 28,
                      decoration: BoxDecoration(color: AppColors.primaryOrange, shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2)),
                      child: const Icon(Icons.edit, color: Colors.white, size: 14)),
                  ]),
                  const SizedBox(height: 10),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(user?.name ?? 'User', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 6),
                    if (user?.isVerified == true)
                      const Icon(Icons.verified, color: Colors.lightBlueAccent, size: 18),
                  ]),
                  Text(user?.roleDisplayName ?? '', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                ]),
              ),
            ),
          ),
          title: const Text('My Profile'),
          actions: [
            IconButton(icon: const Icon(Icons.settings), onPressed: () {}),
          ],
        ),

        SliverList(delegate: SliverChildListDelegate([
          // KYC Status
          const SizedBox(height: 12),
          VerificationBanner(status: user?.verificationStatus.name ?? 'notStarted'),
          const SizedBox(height: 8),

          // Stats
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              _statBox('Free Calls', '${user?.freeCallsLeft ?? 2}', Icons.phone, AppColors.success),
              const SizedBox(width: 10),
              _statBox('Free Chats', '${user?.freeChatsLeft ?? 3}', Icons.chat, AppColors.info),
              const SizedBox(width: 10),
              _statBox('Wallet', '₹${((user?.walletBalance ?? 0) / 100).toStringAsFixed(0)}', Icons.account_balance_wallet, AppColors.primaryOrange),
              const SizedBox(width: 10),
              _statBox('Rating', user?.rating.toStringAsFixed(1) ?? '—', Icons.star, Colors.amber),
            ]),
          ),
          const SizedBox(height: 16),

          // Available toggle (only for workers)
          if (user?.role == UserRole.worker)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 6)]),
                child: Row(children: [
                  const Icon(Icons.work, color: AppColors.primaryGreen),
                  const SizedBox(width: 12),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('काम के लिए Available', style: TextStyle(fontWeight: FontWeight.bold)),
                    Text('ON करने पर आपकी location दिखेगी', style: TextStyle(color: AppColors.grey, fontSize: 12)),
                  ])),
                  Switch(
                    value: _isAvailable,
                    onChanged: (v) {
                      setState(() => _isAvailable = v);
                      auth.updateProfile(isAvailableForWork: v);
                    },
                    activeColor: AppColors.primaryGreen),
                ]),
              ),
            ),
          const SizedBox(height: 8),

          // Skills (for workers)
          if (user?.role == UserRole.worker && (user?.skills.isNotEmpty ?? false))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('मेरी Skills:', style: AppTextStyles.heading3),
                const SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: (user?.skills ?? []).map((s) =>
                  SkillChip(skill: s, isSelected: true)).toList()),
              ]),
            ),

          // Menu items
          const SizedBox(height: 8),
          _menuCard([
            _MenuItem(Icons.account_circle, 'Profile Edit करें', () {}),
            _MenuItem(Icons.badge, 'KYC Verification', () => Navigator.pushNamed(context, '/kyc')),
            _MenuItem(Icons.account_balance_wallet, 'Wallet Recharge करें', () => Navigator.pushNamed(context, '/payment')),
            _MenuItem(Icons.trending_up, 'Leads खरीदें', () => Navigator.pushNamed(context, '/leads')),
          ]),
          const SizedBox(height: 8),
          _menuCard([
            _MenuItem(Icons.star_outline, 'Ratings & Reviews', () {}),
            _MenuItem(Icons.history, 'Activity History', () {}),
            _MenuItem(Icons.help_outline, 'Help & Support', () {}),
            _MenuItem(Icons.privacy_tip_outlined, 'Privacy Policy', () => Navigator.pushNamed(context, '/privacy')),
          ]),
          const SizedBox(height: 8),
          _menuCard([
            _MenuItem(Icons.logout, 'Logout', () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Logout?'),
                  content: const Text('क्या आप Logout करना चाहते हैं?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('नहीं')),
                    TextButton(onPressed: () => Navigator.pop(context, true),
                      child: const Text('हाँ', style: TextStyle(color: AppColors.error))),
                  ]));
              if (confirm == true && context.mounted) {
                await context.read<AuthProvider>().signOut();
                Navigator.pushReplacementNamed(context, '/login');
              }
            }, isDestructive: true),
          ]),
          const SizedBox(height: 30),
          const Center(child: Text('मजदूर सेतु v1.0.0\nकाम की तलाश नहीं, समाधान का रास्ता',
            style: TextStyle(color: AppColors.grey, fontSize: 12), textAlign: TextAlign.center)),
          const SizedBox(height: 20),
        ])),
      ]),
    );
  }

  Widget _statBox(String label, String value, IconData icon, Color color) {
    return Expanded(child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4)]),
      child: Column(children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: color)),
        Text(label, style: const TextStyle(fontSize: 9, color: AppColors.grey), textAlign: TextAlign.center),
      ]),
    ));
  }

  Widget _menuCard(List<_MenuItem> items) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6)]),
      child: Column(
        children: items.asMap().entries.map((e) {
          final item = e.value;
          final isLast = e.key == items.length - 1;
          return Column(children: [
            ListTile(
              onTap: item.onTap,
              leading: Icon(item.icon, color: item.isDestructive ? AppColors.error : AppColors.primaryGreen),
              title: Text(item.label, style: TextStyle(
                color: item.isDestructive ? AppColors.error : AppColors.black,
                fontWeight: FontWeight.w500)),
              trailing: Icon(Icons.chevron_right, color: item.isDestructive ? AppColors.error : AppColors.grey),
            ),
            if (!isLast) const Divider(height: 1, indent: 56),
          ]);
        }).toList(),
      ),
    );
  }
}

class _MenuItem {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDestructive;
  const _MenuItem(this.icon, this.label, this.onTap, {this.isDestructive = false});
}
