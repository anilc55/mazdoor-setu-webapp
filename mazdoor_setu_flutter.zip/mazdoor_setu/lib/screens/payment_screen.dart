import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});
  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(
        title: const Text('Recharge & Plans'),
        backgroundColor: AppColors.primaryGreen,
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: 'Call/Chat'),
            Tab(text: 'Leads'),
            Tab(text: 'Room Listing'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _CallChatPlans(),
          _LeadsPlans(),
          _RoomListingPlans(),
        ],
      ),
    );
  }
}

class _CallChatPlans extends StatelessWidget {
  final _plans = const [
    {'name': 'Basic', 'calls': 10, 'chats': 15, 'price': 49, 'popular': false, 'validity': '30 दिन'},
    {'name': 'Standard', 'calls': 25, 'chats': 40, 'price': 99, 'popular': true, 'validity': '30 दिन'},
    {'name': 'Premium', 'calls': 60, 'chats': 100, 'price': 199, 'popular': false, 'validity': '60 दिन'},
    {'name': 'Unlimited', 'calls': 999, 'chats': 999, 'price': 399, 'popular': false, 'validity': '90 दिन'},
  ];

  const _CallChatPlans();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _FreeInfo(
          title: 'आपके Free Credits',
          items: ['2 Free Calls बचे हैं', '3 Free Chats बचे हैं'],
        ),
        const SizedBox(height: 16),
        ..._plans.map((p) => _PlanCard(
          name: p['name'].toString(),
          description: '${p['calls']} Calls + ${p['chats']} Chats\nValidity: ${p['validity']}',
          price: p['price'] as int,
          isPopular: p['popular'] as bool,
          onBuy: () => _buyPlan(context, p['price'] as int),
        )),
      ],
    );
  }

  void _buyPlan(BuildContext context, int price) {
    _showPaymentDialog(context, price, () {
      context.read<AuthProvider>().addWalletBalance(price * 100);
    });
  }
}

class _LeadsPlans extends StatelessWidget {
  final _packs = const [
    {'leads': 5, 'price': 10, 'popular': false},
    {'leads': 15, 'price': 25, 'popular': true},
    {'leads': 30, 'price': 45, 'popular': false},
    {'leads': 60, 'price': 80, 'popular': false},
  ];

  const _LeadsPlans();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3))),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('🎯 Lead क्या है?', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryOrange)),
            SizedBox(height: 6),
            Text('Lead खरीदने पर आपको customer का direct contact मिलता है।\n₹2 per lead — सीधे customer से बात करें।',
              style: TextStyle(fontSize: 13, color: AppColors.darkGrey)),
          ]),
        ),
        const SizedBox(height: 16),
        ..._packs.map((p) => _PlanCard(
          name: '${p['leads']} Leads Pack',
          description: '₹${2} per lead\nTotal: ${p['leads']} Leads',
          price: p['price'] as int,
          isPopular: p['popular'] as bool,
          onBuy: () => _showPaymentDialog(context, p['price'] as int, () {}),
        )),
      ],
    );
  }
}

class _RoomListingPlans extends StatelessWidget {
  final _plans = const [
    {'days': 10, 'price': 10, 'popular': false},
    {'days': 30, 'price': 20, 'popular': true},
    {'days': 90, 'price': 50, 'popular': false},
  ];

  const _RoomListingPlans();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppColors.success.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12)),
          child: const Row(children: [
            Icon(Icons.home, color: AppColors.success),
            SizedBox(width: 10),
            Expanded(child: Text('पहली Room Listing → FREE (10 दिन)\nउसके बाद आप नीचे के Plans चुनें।',
              style: TextStyle(fontSize: 13, color: AppColors.darkGrey))),
          ]),
        ),
        const SizedBox(height: 16),
        ..._plans.map((p) => _PlanCard(
          name: '${p['days']} दिन Room Listing',
          description: 'आपका रूम ${p['days']} दिन तक सभी को दिखेगा।',
          price: p['price'] as int,
          isPopular: p['popular'] as bool,
          onBuy: () => _showPaymentDialog(context, p['price'] as int, () {}),
        )),
      ],
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String name, description;
  final int price;
  final bool isPopular;
  final VoidCallback onBuy;

  const _PlanCard({required this.name, required this.description, required this.price, required this.isPopular, required this.onBuy});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isPopular ? AppColors.primaryOrange : AppColors.lightGrey,
              width: isPopular ? 2 : 1),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)]),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                Text(description, style: const TextStyle(color: AppColors.grey, fontSize: 13, height: 1.4)),
              ])),
              const SizedBox(width: 12),
              Column(children: [
                Text('₹$price', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primaryGreen)),
                const SizedBox(height: 6),
                ElevatedButton(
                  onPressed: onBuy,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isPopular ? AppColors.primaryOrange : AppColors.primaryGreen,
                    minimumSize: const Size(70, 36),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                  child: const Text('Buy', style: TextStyle(fontWeight: FontWeight.bold))),
              ]),
            ]),
          ),
        ),
        if (isPopular)
          Positioned(top: 0, right: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: const BoxDecoration(
                color: AppColors.primaryOrange,
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8), bottomRight: Radius.circular(8))),
              child: const Text('🔥 Popular', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)))),
      ],
    );
  }
}

class _FreeInfo extends StatelessWidget {
  final String title;
  final List<String> items;
  const _FreeInfo({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.success.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.success.withOpacity(0.3))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.success)),
        const SizedBox(height: 6),
        ...items.map((i) => Text('✓ $i', style: const TextStyle(fontSize: 13, color: AppColors.darkGrey))),
      ]),
    );
  }
}

void _showPaymentDialog(BuildContext context, int amount, VoidCallback onSuccess) {
  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Payment', textAlign: TextAlign.center),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.payment, size: 50, color: AppColors.primaryGreen),
        const SizedBox(height: 12),
        Text('₹$amount', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: AppColors.primaryGreen)),
        const SizedBox(height: 8),
        const Text('Razorpay से Secure Payment', style: TextStyle(color: AppColors.grey, fontSize: 13)),
      ]),
      actions: [
        OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
            // Razorpay.open(options);
            onSuccess();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Payment Successful! ✓'), backgroundColor: AppColors.success));
          },
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryGreen),
          child: const Text('Pay Now')),
      ],
    ),
  );
}
