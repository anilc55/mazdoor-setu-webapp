import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class PrivacyPolicyScreen extends StatefulWidget {
  const PrivacyPolicyScreen({super.key});
  @override
  State<PrivacyPolicyScreen> createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends State<PrivacyPolicyScreen> {
  bool _accepted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.darkGreen, AppColors.primaryGreen],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
              ),
              child: const Column(children: [
                Icon(Icons.security, color: Colors.white, size: 48),
                SizedBox(height: 8),
                Text('Privacy Policy & Terms', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text('कृपया ध्यान से पढ़ें', style: TextStyle(color: Colors.white70, fontSize: 13)),
              ]),
            ),

            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _section('🔐 डेटा सुरक्षा', 'आपका सारा डेटा (नाम, नंबर, लोकेशन, KYC दस्तावेज़) हमारे सुरक्षित सर्वर पर Encrypted रूप में स्टोर होता है। हम किसी भी तीसरी पार्टी को आपका डेटा नहीं बेचते।'),
                  _section('⚖️ कानूनी प्रावधान', 'यदि कोई user platform का दुरुपयोग करता है या किसी आपराधिक गतिविधि में संलिप्त पाया जाता है, तो भारतीय कानून के अनुसार संबंधित डेटा सरकारी/पुलिस प्रशासन को प्रदान किया जा सकता है।'),
                  _section('📱 OTP Verification', 'आपका मोबाइल नंबर केवल OTP Verification के लिए उपयोग होता है। हम आपको spam calls या messages नहीं करते।'),
                  _section('📍 Location Access', 'App आपकी Location का उपयोग केवल नज़दीकी मजदूर/काम/रूम दिखाने के लिए करती है।'),
                  _section('💰 Payment', 'सभी Payments Razorpay के माध्यम से सुरक्षित रूप से process होती हैं। हम आपके कार्ड की जानकारी save नहीं करते।'),
                  _section('🚫 प्रतिबंधित गतिविधियाँ', 'गलत जानकारी देना, fake identity बनाना, harassment करना, या illegal activities करना सख्त मना है और इसके लिए account permanently ban किया जाएगा।'),
                  _section('📞 Contact', 'किसी भी समस्या के लिए: support@mazdoorsetu.in\nAdmin Panel: admin.mazdoorsetu.in'),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.primaryGreen.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.primaryGreen.withOpacity(0.3)),
                    ),
                    child: Row(children: [
                      Checkbox(
                        value: _accepted,
                        onChanged: (v) => setState(() => _accepted = v ?? false),
                        activeColor: AppColors.primaryGreen,
                      ),
                      const Expanded(
                        child: Text('मैंने Privacy Policy और Terms & Conditions पढ़ लिए हैं और मैं इनसे सहमत हूँ।',
                          style: TextStyle(fontSize: 13, color: AppColors.darkGrey)),
                      ),
                    ]),
                  ),
                ]),
              ),
            ),

            // Accept Button
            Padding(
              padding: const EdgeInsets.all(20),
              child: GreenButton(
                text: 'स्वीकार करें और आगे बढ़ें',
                onPressed: _accepted ? () => Navigator.pushReplacementNamed(context, '/login') : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.primaryGreen)),
        const SizedBox(height: 6),
        Text(content, style: const TextStyle(fontSize: 14, color: AppColors.darkGrey, height: 1.5)),
        const Divider(height: 20),
      ]),
    );
  }
}
