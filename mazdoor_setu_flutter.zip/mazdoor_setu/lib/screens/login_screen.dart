import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _sendOTP() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final success = await auth.sendOTP(_phoneController.text.trim());
    if (success && mounted) {
      Navigator.pushNamed(context, '/otp', arguments: _phoneController.text.trim());
    } else if (mounted && auth.errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(auth.errorMessage!), backgroundColor: AppColors.error));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [AppColors.primaryGreen, AppColors.offWhite],
            stops: [0.0, 0.4],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 30),
                // Logo area
                Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 12, offset: const Offset(0, 4))]),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Image.asset('assets/images/logo.png', errorBuilder: (_, __, ___) =>
                      const Icon(Icons.construction, size: 60, color: AppColors.primaryGreen)),
                  ),
                ),
                const SizedBox(height: 12),
                const Text('मजदूर सेतु', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                const Text('काम की तलाश नहीं, समाधान का रास्ता', style: TextStyle(color: Colors.white80, fontSize: 13)),
                const SizedBox(height: 40),

                // Login Card
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 15, offset: const Offset(0, 5))]),
                  child: Form(
                    key: _formKey,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Login करें', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.black)),
                      const SizedBox(height: 4),
                      const Text('अपना Mobile Number डालें', style: TextStyle(color: AppColors.grey, fontSize: 13)),
                      const SizedBox(height: 24),
                      TextFormField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        maxLength: 10,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: const InputDecoration(
                          labelText: 'Mobile Number',
                          hintText: '9XXXXXXXXX',
                          prefixIcon: Padding(
                            padding: EdgeInsets.all(14),
                            child: Text('+91', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryGreen, fontSize: 16)),
                          ),
                          counterText: '',
                        ),
                        validator: (v) {
                          if (v == null || v.isEmpty) return 'Mobile number डालें';
                          if (v.length != 10) return '10 अंकों का नंबर डालें';
                          if (!v.startsWith(RegExp(r'[6-9]'))) return 'Valid mobile number डालें';
                          return null;
                        },
                      ),
                      const SizedBox(height: 24),
                      GreenButton(
                        text: 'OTP भेजें',
                        isLoading: auth.isLoading,
                        icon: Icons.sms,
                        onPressed: _sendOTP,
                      ),
                      const SizedBox(height: 16),
                      const Center(
                        child: Text('OTP आपके Mobile पर SMS द्वारा आएगा',
                          style: TextStyle(color: AppColors.grey, fontSize: 12), textAlign: TextAlign.center),
                      ),
                    ]),
                  ),
                ),
                const SizedBox(height: 30),

                // Features row
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _feature(Icons.work, 'काम\nढूंढें'),
                      _feature(Icons.people, 'मजदूर\nखोजें'),
                      _feature(Icons.home, 'किराये\nका रूम'),
                      _feature(Icons.verified, 'Verified\nProfiles'),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _feature(IconData icon, String label) {
    return Column(children: [
      Container(width: 52, height: 52,
        decoration: BoxDecoration(color: AppColors.primaryGreen.withOpacity(0.1), shape: BoxShape.circle),
        child: Icon(icon, color: AppColors.primaryGreen, size: 26)),
      const SizedBox(height: 6),
      Text(label, textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 11, color: AppColors.darkGrey, fontWeight: FontWeight.w500)),
    ]);
  }
}
