import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class KycScreen extends StatefulWidget {
  const KycScreen({super.key});
  @override
  State<KycScreen> createState() => _KycScreenState();
}

class _KycScreenState extends State<KycScreen> {
  String? _aadharPath;
  String? _selfiePath;
  String _docType = 'Aadhaar';
  int _step = 0;

  Future<void> _pickDocument() async {
    // In real app: use image_picker or file_picker
    // final result = await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() => _aadharPath = 'selected_document.jpg');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Document selected ✓'), backgroundColor: AppColors.success));
  }

  Future<void> _takeSelfie() async {
    // In real app: use camera
    // final result = await ImagePicker().pickImage(source: ImageSource.camera);
    setState(() => _selfiePath = 'selfie.jpg');
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Selfie taken ✓'), backgroundColor: AppColors.success));
  }

  Future<void> _submitKYC() async {
    if (_aadharPath == null || _selfiePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('सभी Documents upload करें'), backgroundColor: AppColors.error));
      return;
    }
    final success = await context.read<AuthProvider>().submitKYC(
      aadharPath: _aadharPath!, selfiePath: _selfiePath!);
    if (success && mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          content: const Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.check_circle, color: AppColors.success, size: 60),
            SizedBox(height: 16),
            Text('KYC Submit हो गई!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('24 घंटे में Verify किया जाएगा।\nVerify होने के बाद Call/Chat access मिलेगी।',
              textAlign: TextAlign.center, style: TextStyle(color: AppColors.grey, fontSize: 13)),
          ]),
          actions: [
            TextButton(
              onPressed: () { Navigator.pop(context); Navigator.pushReplacementNamed(context, '/home'); },
              child: const Text('Home जाएं', style: TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold))),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(title: const Text('KYC Verification'), backgroundColor: AppColors.primaryGreen,
        actions: [
          TextButton(
            onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
            child: const Text('बाद में', style: TextStyle(color: Colors.white70))),
        ]),
      body: LoadingOverlay(
        isLoading: auth.isLoading,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Progress
            Row(children: [
              _stepDot(0, 'Document', Icons.badge),
              Expanded(child: Container(height: 2, color: _step >= 1 ? AppColors.primaryGreen : AppColors.lightGrey)),
              _stepDot(1, 'Selfie', Icons.camera_alt),
              Expanded(child: Container(height: 2, color: _step >= 2 ? AppColors.primaryGreen : AppColors.lightGrey)),
              _stepDot(2, 'Submit', Icons.check),
            ]),
            const SizedBox(height: 30),

            // Why verify
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.info.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.info.withOpacity(0.3))),
              child: const Row(children: [
                Icon(Icons.info_outline, color: AppColors.info),
                SizedBox(width: 10),
                Expanded(child: Text(
                  'Verify होने के बाद ही Call, Chat और Leads access होंगे।\nयह platform को safe रखने के लिए जरूरी है।',
                  style: TextStyle(color: AppColors.info, fontSize: 13))),
              ]),
            ),
            const SizedBox(height: 24),

            // Doc type selector
            const Text('ID Document Type:', style: AppTextStyles.heading3),
            const SizedBox(height: 10),
            Wrap(spacing: 10, children: ['Aadhaar', 'PAN', 'Voter ID'].map((type) =>
              ChoiceChip(
                label: Text(type),
                selected: _docType == type,
                onSelected: (_) => setState(() => _docType = type),
                selectedColor: AppColors.primaryGreen,
                labelStyle: TextStyle(color: _docType == type ? Colors.white : AppColors.black),
              )).toList()),
            const SizedBox(height: 20),

            // Document upload
            _uploadCard(
              title: '$_docType Upload करें',
              subtitle: 'Front side clear photo',
              icon: Icons.badge_outlined,
              isUploaded: _aadharPath != null,
              onTap: _pickDocument,
            ),
            const SizedBox(height: 16),

            // Selfie
            _uploadCard(
              title: 'Live Selfie',
              subtitle: 'Camera से Live photo लें',
              icon: Icons.camera_front,
              isUploaded: _selfiePath != null,
              onTap: _takeSelfie,
            ),
            const SizedBox(height: 16),

            // Tips
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.warning.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12)),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('📸 Tips:', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.warning)),
                SizedBox(height: 6),
                Text('• Document साफ और पढ़ने योग्य हो\n• Selfie में चेहरा स्पष्ट दिखे\n• Good lighting में photo लें\n• Blur या Cut photo reject होगी',
                  style: TextStyle(fontSize: 13, color: AppColors.darkGrey, height: 1.6)),
              ]),
            ),
            const SizedBox(height: 28),

            GreenButton(
              text: 'KYC Submit करें',
              icon: Icons.upload,
              isLoading: auth.isLoading,
              onPressed: _submitKYC,
            ),
          ]),
        ),
      ),
    );
  }

  Widget _stepDot(int step, String label, IconData icon) {
    final isActive = _step >= step;
    return Column(children: [
      Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color: isActive ? AppColors.primaryGreen : AppColors.lightGrey,
          shape: BoxShape.circle),
        child: Icon(icon, color: isActive ? Colors.white : AppColors.grey, size: 18)),
      const SizedBox(height: 4),
      Text(label, style: TextStyle(fontSize: 11, color: isActive ? AppColors.primaryGreen : AppColors.grey)),
    ]);
  }

  Widget _uploadCard({required String title, required String subtitle, required IconData icon, required bool isUploaded, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isUploaded ? AppColors.success : AppColors.lightGrey,
            width: isUploaded ? 2 : 1),
        ),
        child: Row(children: [
          Container(width: 56, height: 56,
            decoration: BoxDecoration(
              color: (isUploaded ? AppColors.success : AppColors.primaryGreen).withOpacity(0.1),
              borderRadius: BorderRadius.circular(12)),
            child: Icon(isUploaded ? Icons.check_circle : icon,
              color: isUploaded ? AppColors.success : AppColors.primaryGreen, size: 28)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Text(subtitle, style: const TextStyle(color: AppColors.grey, fontSize: 12)),
          ])),
          Icon(isUploaded ? Icons.edit : Icons.upload,
            color: isUploaded ? AppColors.success : AppColors.primaryGreen),
        ]),
      ),
    );
  }
}
