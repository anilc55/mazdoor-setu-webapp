import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  final _demoChats = const [
    {'name': 'राम कुमार', 'lastMsg': 'हाँ भाई, कल से आ सकता हूँ', 'time': '10:30', 'unread': 2, 'role': 'मजदूर'},
    {'name': 'नीता देसाई', 'lastMsg': 'रूम अभी उपलब्ध है', 'time': '9:15', 'unread': 0, 'role': 'रूम ओनर'},
    {'name': 'अजय कंस्ट्रक्शन', 'lastMsg': 'Interview के लिए आ जाइए', 'time': 'कल', 'unread': 1, 'role': 'कंपनी'},
    {'name': 'शिव प्रसाद', 'lastMsg': 'Rate क्या होगा?', 'time': 'कल', 'unread': 0, 'role': 'मजदूर'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(title: const Text('Messages'), backgroundColor: AppColors.primaryGreen,
        actions: [IconButton(icon: const Icon(Icons.search), onPressed: () {})]),
      body: _demoChats.isEmpty
        ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.chat_bubble_outline, size: 80, color: AppColors.lightGrey),
            SizedBox(height: 16),
            Text('कोई Chat नहीं', style: TextStyle(color: AppColors.grey, fontSize: 16)),
            Text('मजदूर या रूम ओनर से Chat शुरू करें', style: TextStyle(color: AppColors.grey, fontSize: 13)),
          ]))
        : ListView.builder(
            itemCount: _demoChats.length,
            itemBuilder: (_, i) {
              final chat = _demoChats[i];
              return ListTile(
                onTap: () => Navigator.pushNamed(context, '/chat', arguments: chat),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                leading: Stack(children: [
                  CircleAvatar(radius: 26,
                    backgroundColor: AppColors.primaryGreen.withOpacity(0.12),
                    child: Text(chat['name'].toString()[0],
                      style: const TextStyle(color: AppColors.primaryGreen, fontSize: 20, fontWeight: FontWeight.bold))),
                  Positioned(bottom: 0, right: 0,
                    child: Container(width: 12, height: 12,
                      decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 1.5)))),
                ]),
                title: Row(children: [
                  Expanded(child: Text(chat['name'].toString(), style: const TextStyle(fontWeight: FontWeight.bold))),
                  Text(chat['time'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                ]),
                subtitle: Row(children: [
                  Text(chat['role'].toString(),
                    style: const TextStyle(color: AppColors.primaryGreen, fontSize: 11, fontWeight: FontWeight.w500)),
                  const Text(' • ', style: TextStyle(color: AppColors.grey)),
                  Expanded(child: Text(chat['lastMsg'].toString(),
                    style: TextStyle(color: (chat['unread'] as int) > 0 ? AppColors.black : AppColors.grey,
                      fontWeight: (chat['unread'] as int) > 0 ? FontWeight.w600 : FontWeight.normal, fontSize: 13),
                    overflow: TextOverflow.ellipsis)),
                  if ((chat['unread'] as int) > 0)
                    Container(
                      padding: const EdgeInsets.all(5),
                      decoration: const BoxDecoration(color: AppColors.primaryGreen, shape: BoxShape.circle),
                      child: Text(chat['unread'].toString(), style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                ]),
              );
            },
          ),
    );
  }
}
