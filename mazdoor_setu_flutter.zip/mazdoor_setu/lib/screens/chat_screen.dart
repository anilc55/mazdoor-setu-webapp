import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  final List<Map<String, dynamic>> _messages = [
    {'msg': 'नमस्ते! काम के बारे में बात करनी थी।', 'isMine': false, 'time': '10:00'},
    {'msg': 'हाँ जी, बताइए। क्या काम है?', 'isMine': true, 'time': '10:02'},
    {'msg': 'दिल्ली में construction का काम है। 3 महीने के लिए।', 'isMine': false, 'time': '10:05'},
    {'msg': 'Rate क्या है? रोज का?', 'isMine': true, 'time': '10:06'},
    {'msg': '₹600/दिन। खाना और रहना अलग।', 'isMine': false, 'time': '10:08'},
  ];

  void _sendMessage() {
    final auth = context.read<AuthProvider>();
    if (!auth.isVerified) { VerifyPopup.show(context); return; }
    if (_msgCtrl.text.trim().isEmpty) return;
    setState(() {
      _messages.add({'msg': _msgCtrl.text.trim(), 'isMine': true, 'time': _timeNow()});
      _msgCtrl.clear();
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  String _timeNow() {
    final now = DateTime.now();
    return '${now.hour}:${now.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map?;
    final name = args?['name'] ?? 'User';
    final role = args?['role'] ?? '';

    return Scaffold(
      backgroundColor: const Color(0xFFECE5DD),
      appBar: AppBar(
        backgroundColor: AppColors.primaryGreen,
        title: Row(children: [
          CircleAvatar(radius: 18, backgroundColor: Colors.white,
            child: Text(name[0], style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold))),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            Text(role, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ]),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.phone), onPressed: () {
            final auth = context.read<AuthProvider>();
            if (!auth.isVerified) { VerifyPopup.show(context); return; }
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Calling...'), backgroundColor: AppColors.success));
          }),
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      body: Column(children: [
        // Free chats info
        Container(
          color: AppColors.warning.withOpacity(0.1),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.info_outline, size: 14, color: AppColors.warning),
            SizedBox(width: 6),
            Text('2 Free Chats बचे हैं। बाद में Paid होगा।',
              style: TextStyle(color: AppColors.warning, fontSize: 12)),
          ]),
        ),

        // Messages
        Expanded(
          child: ListView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            itemCount: _messages.length,
            itemBuilder: (_, i) {
              final m = _messages[i];
              final isMine = m['isMine'] as bool;
              return Align(
                alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: isMine ? const Color(0xFFDCF8C6) : Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isMine ? 16 : 4),
                      bottomRight: Radius.circular(isMine ? 4 : 16)),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 4)]),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(m['msg'].toString(), style: const TextStyle(fontSize: 15, color: AppColors.black)),
                    const SizedBox(height: 3),
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(m['time'].toString(), style: const TextStyle(fontSize: 11, color: AppColors.grey)),
                      if (isMine) ...[
                        const SizedBox(width: 4),
                        const Icon(Icons.done_all, size: 14, color: AppColors.info)],
                    ]),
                  ]),
                ),
              );
            },
          ),
        ),

        // Input bar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          decoration: const BoxDecoration(color: Colors.white,
            boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, -1))]),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.attach_file, color: AppColors.grey), onPressed: () {}),
            Expanded(
              child: TextField(
                controller: _msgCtrl,
                decoration: InputDecoration(
                  hintText: 'Message लिखें...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                  filled: true, fillColor: AppColors.offWhite,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
                maxLines: 3, minLines: 1,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: _sendMessage,
              child: Container(
                width: 46, height: 46,
                decoration: const BoxDecoration(color: AppColors.primaryGreen, shape: BoxShape.circle),
                child: const Icon(Icons.send, color: Colors.white, size: 20))),
          ]),
        ),
      ]),
    );
  }
}
