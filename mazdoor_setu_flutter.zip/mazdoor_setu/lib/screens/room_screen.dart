import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import '../providers/app_provider.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';

class RoomListScreen extends StatefulWidget {
  const RoomListScreen({super.key});

  @override
  State<RoomListScreen> createState() => _RoomListScreenState();
}

class _RoomListScreenState extends State<RoomListScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppProvider>().currentUser;
    final isOwner = user?.role == UserRole.roomOwner;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('🏠 Rooms'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.accentOrange,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          tabs: [
            const Tab(text: 'All Rooms'),
            Tab(text: isOwner ? 'मेरे Rooms' : 'Saved'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _AllRoomsTab(),
          isOwner ? _MyRoomsTab() : _AllRoomsTab(),
        ],
      ),
      floatingActionButton: isOwner
          ? FloatingActionButton.extended(
              onPressed: () => _showAddRoomSheet(context),
              backgroundColor: AppColors.accentOrange,
              icon: const Icon(Icons.add),
              label: const Text('Room जोड़ें'),
            )
          : null,
    );
  }

  void _showAddRoomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const _AddRoomSheet(),
    );
  }
}

// ─── All Rooms Tab ───────────────────────────
class _AllRoomsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final rooms = context.watch<AppProvider>().getPublicRooms();

    if (rooms.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('🏠', style: TextStyle(fontSize: 60)),
            SizedBox(height: 16),
            Text('कोई Room नहीं मिला',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('अभी कोई Room available नहीं है',
                style: TextStyle(color: AppColors.textSecondary)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: rooms.length,
      itemBuilder: (ctx, i) => _RoomCard(room: rooms[i]),
    );
  }
}

// ─── My Rooms Tab ─────────────────────────────
class _MyRoomsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final rooms = context.watch<AppProvider>().getMyRooms();

    if (rooms.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🏠', style: TextStyle(fontSize: 60)),
            const SizedBox(height: 16),
            const Text('कोई Room नहीं जोड़ा',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('+Room जोड़ें बटन दबाएं',
                style: TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.symmetric(horizontal: 32),
              decoration: BoxDecoration(
                color: AppColors.accentOrange.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: AppColors.accentOrange.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  const Text('💰 Pricing',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('पहला Post: 10 दिन FREE',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                  const Text('₹10 = 10 दिन',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                  const Text('₹20 = 30 दिन',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: rooms.length,
      itemBuilder: (ctx, i) => _MyRoomCard(room: rooms[i]),
    );
  }
}

// ─── Room Card ────────────────────────────────
class _RoomCard extends StatelessWidget {
  final RoomListing room;
  const _RoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image placeholder
          Container(
            height: 160,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.primaryGreen.withOpacity(0.3),
                  AppColors.accentOrange.withOpacity(0.2),
                ],
              ),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            ),
            child: Stack(
              children: [
                const Center(
                  child: Text('🏠', style: TextStyle(fontSize: 60)),
                ),
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.success,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      '✅ Available',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.navyBlue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      room.roomTypeLabel,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  room.title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.location_on_outlined,
                        size: 14, color: AppColors.grey),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        room.address,
                        style: const TextStyle(
                            fontSize: 12, color: AppColors.textSecondary),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // Facilities
                if (room.facilities.isNotEmpty)
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: room.facilities.take(4).map((f) {
                      return Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(f,
                            style: const TextStyle(fontSize: 11)),
                      );
                    }).toList(),
                  ),

                const SizedBox(height: 12),
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '₹${room.pricePerMonth}/month',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primaryGreen,
                          ),
                        ),
                        Text('👁 ${room.views} views',
                            style: const TextStyle(
                                fontSize: 11,
                                color: AppColors.grey)),
                      ],
                    ),
                    const Spacer(),
                    OutlinedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.call_outlined, size: 16),
                      label: const Text('Contact'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.primaryGreen,
                        side: const BorderSide(
                            color: AppColors.primaryGreen),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        minimumSize: Size.zero,
                        textStyle: const TextStyle(fontSize: 13),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.chat_bubble_outline, size: 16),
                      label: const Text('Chat'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accentOrange,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        minimumSize: Size.zero,
                        textStyle: const TextStyle(fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── My Room Card (Owner view) ────────────────
class _MyRoomCard extends StatelessWidget {
  final RoomListing room;
  const _MyRoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final isPublished = room.status == RoomStatus.published;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: AppColors.accentOrange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                      child: Text('🏠', style: TextStyle(fontSize: 28))),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(room.title,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Text('₹${room.pricePerMonth}/month',
                          style: const TextStyle(
                              color: AppColors.primaryGreen,
                              fontWeight: FontWeight.bold)),
                      Text(room.roomTypeLabel,
                          style: const TextStyle(
                              fontSize: 12,
                              color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: isPublished
                        ? AppColors.success.withOpacity(0.1)
                        : AppColors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    isPublished ? '🟢 Published' : '🔒 Saved',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: isPublished
                          ? AppColors.success
                          : AppColors.grey,
                    ),
                  ),
                ),
              ],
            ),
            if (!isPublished) ...[
              const SizedBox(height: 12),
              const Divider(height: 1),
              const SizedBox(height: 12),
              // Publish options
              const Text('Publish करें:',
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _PublishOption(
                      label: 'FREE',
                      subtitle: '10 दिन',
                      price: 0,
                      isFree: true,
                      onTap: () {
                        context
                            .read<AppProvider>()
                            .publishRoom(room.id);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('✅ Room Publish हो गया! (10 दिन Free)'),
                            backgroundColor: AppColors.success,
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _PublishOption(
                      label: '₹10',
                      subtitle: '10 दिन',
                      price: 10,
                      onTap: () => _showPaymentDialog(context, 10, 10),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _PublishOption(
                      label: '₹20',
                      subtitle: '30 दिन',
                      price: 20,
                      isPopular: true,
                      onTap: () => _showPaymentDialog(context, 20, 30),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showPaymentDialog(BuildContext ctx, int price, int days) {
    showDialog(
      context: ctx,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('₹$price में $days दिन के लिए Publish करें?'),
        content: Text(
          'आपके wallet से ₹$price कट जाएंगे।\nRoom $days दिन तक दिखेगा।',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(_),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(_);
              ctx.read<AppProvider>().publishRoom(room.id);
              ScaffoldMessenger.of(ctx).showSnackBar(
                SnackBar(
                  content: Text('✅ Room Publish! $days दिन के लिए।'),
                  backgroundColor: AppColors.success,
                ),
              );
            },
            child: const Text('Pay & Publish'),
          ),
        ],
      ),
    );
  }
}

// ─── Publish Option Widget ────────────────────
class _PublishOption extends StatelessWidget {
  final String label;
  final String subtitle;
  final int price;
  final bool isFree;
  final bool isPopular;
  final VoidCallback onTap;

  const _PublishOption({
    required this.label,
    required this.subtitle,
    required this.price,
    required this.onTap,
    this.isFree = false,
    this.isPopular = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isFree
              ? AppColors.primaryGreen.withOpacity(0.1)
              : isPopular
                  ? AppColors.accentOrange.withOpacity(0.1)
                  : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isFree
                ? AppColors.primaryGreen
                : isPopular
                    ? AppColors.accentOrange
                    : AppColors.lightGrey,
            width: isPopular ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            if (isPopular)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.accentOrange,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'Best',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.bold),
                ),
              ),
            Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isFree
                    ? AppColors.primaryGreen
                    : isPopular
                        ? AppColors.accentOrange
                        : AppColors.textPrimary,
                fontSize: 14,
              ),
            ),
            Text(
              subtitle,
              style: const TextStyle(
                  fontSize: 10, color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Add Room Sheet ──────────────────────────
class _AddRoomSheet extends StatefulWidget {
  const _AddRoomSheet();

  @override
  State<_AddRoomSheet> createState() => _AddRoomSheetState();
}

class _AddRoomSheetState extends State<_AddRoomSheet> {
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();

  RoomType _roomType = RoomType.single;
  List<String> _selectedFacilities = [];
  List<File> _photos = [];
  bool _isSaving = false;

  final List<String> _allFacilities = [
    'पानी', 'बिजली', 'WiFi', 'किचन', 'शौचालय',
    'पंखा', 'AC', 'पार्किंग', 'बालकनी', 'लॉकर',
    'Washing Machine', 'Geyser',
  ];

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _priceCtrl.dispose();
    _addressCtrl.dispose();
    _cityCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhotos() async {
    final picker = ImagePicker();
    final imgs = await picker.pickMultiImage(imageQuality: 80, limit: 5);
    if (imgs.isNotEmpty) {
      setState(() => _photos = imgs.map((e) => File(e.path)).toList());
    }
  }

  Future<void> _saveRoom() async {
    if (_titleCtrl.text.trim().isEmpty) {
      _showSnack('Room का title भरें');
      return;
    }
    if (_priceCtrl.text.isEmpty) {
      _showSnack('Price भरें');
      return;
    }
    if (_cityCtrl.text.trim().isEmpty) {
      _showSnack('City भरें');
      return;
    }

    setState(() => _isSaving = true);
    await Future.delayed(const Duration(milliseconds: 500));

    final provider = context.read<AppProvider>();
    final user = provider.currentUser!;

    final room = RoomListing(
      id: 'r_${DateTime.now().millisecondsSinceEpoch}',
      ownerId: user.id,
      ownerName: user.name,
      ownerPhone: user.phone,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      roomType: _roomType,
      pricePerMonth: int.tryParse(_priceCtrl.text) ?? 0,
      address: _addressCtrl.text.trim(),
      city: _cityCtrl.text.trim(),
      facilities: _selectedFacilities,
      photos: _photos.map((f) => f.path).toList(),
      status: RoomStatus.saved,
    );

    provider.addRoom(room);
    if (mounted) {
      setState(() => _isSaving = false);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Room save हो गया! अब Publish करें।'),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppColors.warning),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      expand: false,
      builder: (_, scrollCtrl) => Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.lightGrey,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Row(
              children: [
                const Text('🏠 Room जोड़ें',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              controller: scrollCtrl,
              padding: const EdgeInsets.all(20),
              children: [
                // Room Type
                const Text('Room का प्रकार:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Row(
                  children: RoomType.values.map((type) {
                    final isSelected = _roomType == type;
                    String label;
                    switch (type) {
                      case RoomType.single: label = 'Single';
                      case RoomType.shared: label = 'Shared';
                      case RoomType.family: label = 'Family';
                      case RoomType.dormitory: label = 'Dorm';
                    }
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _roomType = type),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.accentOrange
                                : Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isSelected
                                  ? AppColors.accentOrange
                                  : AppColors.lightGrey,
                            ),
                          ),
                          child: Text(
                            label,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white
                                  : AppColors.textPrimary,
                              fontSize: 12,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),

                TextField(
                  controller: _titleCtrl,
                  decoration: const InputDecoration(labelText: 'Room Title *'),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _descCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Description (विवरण)',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _priceCtrl,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    labelText: 'Price (₹/month) *',
                    prefixText: '₹ ',
                  ),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _addressCtrl,
                  decoration:
                      const InputDecoration(labelText: 'Address / पता'),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _cityCtrl,
                  decoration: const InputDecoration(labelText: 'City / शहर *'),
                ),
                const SizedBox(height: 20),

                // Facilities
                const Text('सुविधाएं चुनें:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _allFacilities.map((f) {
                    final isSelected = _selectedFacilities.contains(f);
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          if (isSelected) {
                            _selectedFacilities.remove(f);
                          } else {
                            _selectedFacilities.add(f);
                          }
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.primaryGreen
                              : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isSelected
                                ? AppColors.primaryGreen
                                : AppColors.lightGrey,
                          ),
                        ),
                        child: Text(
                          f,
                          style: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : AppColors.textPrimary,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),

                // Photo upload
                const Text('Photos Upload करें:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                GestureDetector(
                  onTap: _pickPhotos,
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppColors.primaryGreen.withOpacity(0.4),
                        style: BorderStyle.solid,
                      ),
                    ),
                    child: _photos.isEmpty
                        ? const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.photo_library_outlined,
                                  size: 32,
                                  color: AppColors.primaryGreen),
                              SizedBox(height: 6),
                              Text('Gallery से Photos चुनें',
                                  style: TextStyle(
                                      color: AppColors.primaryGreen,
                                      fontSize: 13)),
                            ],
                          )
                        : ListView.builder(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.all(8),
                            itemCount: _photos.length,
                            itemBuilder: (_, i) => Container(
                              margin: const EdgeInsets.only(right: 8),
                              width: 80,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                image: DecorationImage(
                                  image: FileImage(_photos[i]),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(
                20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
            child: ElevatedButton(
              onPressed: _isSaving ? null : _saveRoom,
              style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.accentOrange),
              child: _isSaving
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2.5),
                    )
                  : const Text('Room Save करें 🏠'),
            ),
          ),
        ],
      ),
    );
  }
}
