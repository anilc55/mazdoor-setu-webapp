import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class WorkerListingScreen extends StatefulWidget {
  const WorkerListingScreen({super.key});
  @override
  State<WorkerListingScreen> createState() => _WorkerListingScreenState();
}

class _WorkerListingScreenState extends State<WorkerListingScreen> {
  String _selectedSkill = 'सभी';
  bool _onlyAvailable = false;

  final _demoWorkers = [
    {'name': 'राम कुमार', 'skills': ['राजमिस्त्री', 'Helper'], 'location': 'करोल बाग, दिल्ली', 'rating': 4.8, 'available': true, 'calls': 2, 'verified': true, 'experience': '8 साल'},
    {'name': 'शिव प्रसाद', 'skills': ['प्लंबर'], 'location': 'अंधेरी, मुंबई', 'rating': 4.5, 'available': true, 'calls': 2, 'verified': true, 'experience': '5 साल'},
    {'name': 'मोहन लाल', 'skills': ['पेंटर', 'Helper'], 'location': 'मालवीय नगर, जयपुर', 'rating': 4.7, 'available': false, 'calls': 1, 'verified': true, 'experience': '10 साल'},
    {'name': 'सुरेश यादव', 'skills': ['इलेक्ट्रीशियन'], 'location': 'लखनऊ', 'rating': 4.3, 'available': true, 'calls': 2, 'verified': false, 'experience': '3 साल'},
    {'name': 'अजय सिंह', 'skills': ['कारपेंटर', 'Furniture Maker'], 'location': 'पुणे', 'rating': 4.9, 'available': true, 'calls': 2, 'verified': true, 'experience': '12 साल'},
    {'name': 'विजय कुमार', 'skills': ['वेल्डर'], 'location': 'सूरत', 'rating': 4.6, 'available': false, 'calls': 0, 'verified': true, 'experience': '7 साल'},
  ];

  void _handleCall(BuildContext context, Map<String, dynamic> worker) {
    final auth = context.read<AuthProvider>();
    if (!auth.isVerified) { VerifyPopup.show(context); return; }
    if (!auth.canMakeCall()) {
      Navigator.pushNamed(context, '/payment');
      return;
    }
    auth.decrementFreeCall();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Call connecting...'), backgroundColor: AppColors.success));
    // url_launcher: launch('tel:+91XXXXXXXXXX');
  }

  void _handleChat(BuildContext context, Map<String, dynamic> worker) {
    final auth = context.read<AuthProvider>();
    if (!auth.isVerified) { VerifyPopup.show(context); return; }
    if (!auth.canChat()) {
      Navigator.pushNamed(context, '/payment');
      return;
    }
    Navigator.pushNamed(context, '/chat', arguments: worker);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      appBar: AppBar(
        title: const Text('मजदूर खोजें'),
        backgroundColor: AppColors.primaryGreen,
        actions: [
          IconButton(icon: const Icon(Icons.filter_list), onPressed: () {}),
        ],
      ),
      body: Column(
        children: [
          // Filter bar
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(children: ['सभी', ...AppSkills.allSkills.take(8)].map((s) =>
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(s, style: TextStyle(fontSize: 12, color: _selectedSkill == s ? Colors.white : AppColors.darkGrey)),
                      selected: _selectedSkill == s,
                      onSelected: (_) => setState(() => _selectedSkill = s),
                      backgroundColor: AppColors.lightGrey,
                      selectedColor: AppColors.primaryGreen,
                      checkmarkColor: Colors.white,
                    ),
                  )).toList()),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Row(children: [
                  Switch(value: _onlyAvailable, onChanged: (v) => setState(() => _onlyAvailable = v),
                    activeColor: AppColors.primaryGreen),
                  const Text('केवल Available मजदूर दिखाएं', style: TextStyle(fontSize: 13)),
                  const Spacer(),
                  Text('${_demoWorkers.length} मिले', style: const TextStyle(color: AppColors.grey, fontSize: 13)),
                ]),
              ),
            ]),
          ),

          // Worker list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _demoWorkers.length,
              itemBuilder: (_, i) {
                final w = _demoWorkers[i];
                final isVerified = w['verified'] as bool;
                final isAvailable = w['available'] as bool;
                final skills = w['skills'] as List<String>;
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(children: [
                      Row(children: [
                        Stack(children: [
                          CircleAvatar(radius: 28, backgroundColor: AppColors.primaryGreen.withOpacity(0.12),
                            child: Text(w['name'].toString()[0],
                              style: const TextStyle(color: AppColors.primaryGreen, fontSize: 22, fontWeight: FontWeight.bold))),
                          if (isAvailable)
                            Positioned(bottom: 1, right: 1,
                              child: Container(width: 12, height: 12,
                                decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 1.5)))),
                        ]),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Text(w['name'].toString(), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            if (isVerified) ...[
                              const SizedBox(width: 4),
                              const Icon(Icons.verified, color: AppColors.info, size: 16),
                            ],
                          ]),
                          Text('अनुभव: ${w['experience']}', style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                          Row(children: [
                            const Icon(Icons.location_on, size: 13, color: AppColors.grey),
                            Text(w['location'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                          ]),
                        ])),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Row(children: [
                            const Icon(Icons.star, color: Colors.amber, size: 14),
                            Text(' ${w['rating']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          ]),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: (isAvailable ? AppColors.success : AppColors.grey).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6)),
                            child: Text(isAvailable ? 'Available' : 'Busy',
                              style: TextStyle(color: isAvailable ? AppColors.success : AppColors.grey, fontSize: 11, fontWeight: FontWeight.w600))),
                        ]),
                      ]),
                      const SizedBox(height: 10),
                      // Skills
                      Wrap(spacing: 6, children: skills.map((s) => Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.primaryGreen.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(12)),
                        child: Text(s, style: const TextStyle(fontSize: 11, color: AppColors.primaryGreen, fontWeight: FontWeight.w500)),
                      )).toList()),
                      const SizedBox(height: 12),
                      // Action buttons
                      Row(children: [
                        Expanded(child: OutlinedButton.icon(
                          onPressed: () => _handleCall(context, w),
                          icon: const Icon(Icons.phone, size: 16),
                          label: Text('Call ${(w['calls'] as int) > 0 ? "(${w['calls']} Free)" : "(Paid)"}'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.primaryGreen,
                            side: const BorderSide(color: AppColors.primaryGreen),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                        )),
                        const SizedBox(width: 10),
                        Expanded(child: ElevatedButton.icon(
                          onPressed: () => _handleChat(context, w),
                          icon: const Icon(Icons.chat, size: 16),
                          label: const Text('Chat'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryGreen,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                        )),
                      ]),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
