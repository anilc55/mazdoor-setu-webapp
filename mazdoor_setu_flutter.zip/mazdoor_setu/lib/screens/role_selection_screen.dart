import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../models/user_model.dart';
import '../providers/auth_provider.dart';
import '../widgets/common_widgets.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key});
  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen> {
  UserRole? _selectedRole;
  final _nameController = TextEditingController();

  final List<_RoleItem> _roles = [
    _RoleItem(role: UserRole.worker, icon: Icons.construction, title: 'मजदूर', subtitle: 'काम ढूंढना है', color: AppColors.workerColor, emoji: '🧱'),
    _RoleItem(role: UserRole.thekedar, icon: Icons.supervisor_account, title: 'ठेकेदार', subtitle: 'मजदूर ढूंढना है', color: AppColors.thekedaarColor, emoji: '📋'),
    _RoleItem(role: UserRole.company, icon: Icons.business, title: 'कंपनी', subtitle: 'कर्मचारी चाहिए', color: AppColors.companyColor, emoji: '🏢'),
    _RoleItem(role: UserRole.roomOwner, icon: Icons.home, title: 'रूम ओनर', subtitle: 'रूम किराये पर देना है', color: AppColors.roomOwnerColor, emoji: '🏠'),
  ];

  Future<void> _proceed() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('अपना नाम दर्ज करें'), backgroundColor: AppColors.error));
      return;
    }
    if (_selectedRole == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('कृपया अपनी भूमिका चुनें'), backgroundColor: AppColors.error));
      return;
    }
    await context.read<AuthProvider>().setUserRoleAndName(_nameController.text.trim(), _selectedRole!);
    if (mounted) Navigator.pushReplacementNamed(context, '/kyc');
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: AppColors.offWhite,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 10),
            RichText(text: const TextSpan(children: [
              TextSpan(text: 'मजदूर ', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primaryGreen)),
              TextSpan(text: 'सेतु', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primaryOrange)),
            ])),
            const Text('में आपका स्वागत है!', style: TextStyle(fontSize: 16, color: AppColors.grey)),
            const SizedBox(height: 30),

            // Name
            const Text('आपका नाम क्या है?', style: AppTextStyles.heading3),
            const SizedBox(height: 12),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                hintText: 'पूरा नाम लिखें',
                prefixIcon: Icon(Icons.person, color: AppColors.primaryGreen),
              ),
            ),
            const SizedBox(height: 30),

            const Text('आप कौन हैं?', style: AppTextStyles.heading3),
            const SizedBox(height: 4),
            const Text('अपनी भूमिका चुनें', style: AppTextStyles.body),
            const SizedBox(height: 16),

            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, childAspectRatio: 1.1,
                crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemCount: _roles.length,
              itemBuilder: (_, i) {
                final r = _roles[i];
                final isSelected = _selectedRole == r.role;
                return GestureDetector(
                  onTap: () => setState(() => _selectedRole = r.role),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      color: isSelected ? r.color : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected ? r.color : AppColors.lightGrey,
                        width: isSelected ? 2 : 1),
                      boxShadow: [
                        BoxShadow(
                          color: (isSelected ? r.color : Colors.black).withOpacity(isSelected ? 0.3 : 0.05),
                          blurRadius: isSelected ? 12 : 4, offset: const Offset(0, 3)),
                      ],
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(r.emoji, style: const TextStyle(fontSize: 36)),
                      const SizedBox(height: 8),
                      Text(r.title, style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold,
                        color: isSelected ? Colors.white : AppColors.black)),
                      const SizedBox(height: 4),
                      Text(r.subtitle, style: TextStyle(
                        fontSize: 11, color: isSelected ? Colors.white70 : AppColors.grey),
                        textAlign: TextAlign.center),
                      if (isSelected) ...[
                        const SizedBox(height: 6),
                        const Icon(Icons.check_circle, color: Colors.white, size: 20),
                      ],
                    ]),
                  ),
                );
              },
            ),
            const SizedBox(height: 32),
            GreenButton(
              text: 'आगे बढ़ें →',
              isLoading: auth.isLoading,
              onPressed: _proceed,
            ),
          ]),
        ),
      ),
    );
  }
}

class _RoleItem {
  final UserRole role;
  final IconData icon;
  final String title, subtitle, emoji;
  final Color color;
  const _RoleItem({required this.role, required this.icon, required this.title, required this.subtitle, required this.color, required this.emoji});
}
