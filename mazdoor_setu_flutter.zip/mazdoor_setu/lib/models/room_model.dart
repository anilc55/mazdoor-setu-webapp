enum RoomStatus { draft, pending, active, expired }
enum RoomType { single, shared, family, pg }

class RoomModel {
  final String id;
  final String ownerId;
  final String ownerName;
  final String ownerPhone;
  final String title;
  final String description;
  final double rent; // Monthly
  final String location;
  final double latitude;
  final double longitude;
  final RoomType roomType;
  final List<String> photos;
  final String? videoUrl;
  final List<String> facilities;
  final bool isPublic;
  final RoomStatus status;
  final DateTime createdAt;
  final DateTime? expiresAt;
  final double? rating;

  RoomModel({
    required this.id,
    required this.ownerId,
    required this.ownerName,
    required this.ownerPhone,
    required this.title,
    required this.description,
    required this.rent,
    required this.location,
    required this.latitude,
    required this.longitude,
    this.roomType = RoomType.single,
    this.photos = const [],
    this.videoUrl,
    this.facilities = const [],
    this.isPublic = true,
    this.status = RoomStatus.pending,
    required this.createdAt,
    this.expiresAt,
    this.rating,
  });

  bool get isExpired =>
      expiresAt != null && DateTime.now().isAfter(expiresAt!);

  String get roomTypeDisplay {
    switch (roomType) {
      case RoomType.single:
        return 'सिंगल रूम';
      case RoomType.shared:
        return 'शेयर्ड रूम';
      case RoomType.family:
        return 'फैमिली रूम';
      case RoomType.pg:
        return 'PG';
    }
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'ownerId': ownerId,
    'ownerName': ownerName,
    'ownerPhone': ownerPhone,
    'title': title,
    'description': description,
    'rent': rent,
    'location': location,
    'latitude': latitude,
    'longitude': longitude,
    'roomType': roomType.name,
    'photos': photos,
    'videoUrl': videoUrl,
    'facilities': facilities,
    'isPublic': isPublic,
    'status': status.name,
    'createdAt': createdAt.toIso8601String(),
    'expiresAt': expiresAt?.toIso8601String(),
    'rating': rating,
  };

  factory RoomModel.fromMap(Map<String, dynamic> map) => RoomModel(
    id: map['id'] ?? '',
    ownerId: map['ownerId'] ?? '',
    ownerName: map['ownerName'] ?? '',
    ownerPhone: map['ownerPhone'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    rent: (map['rent'] ?? 0).toDouble(),
    location: map['location'] ?? '',
    latitude: (map['latitude'] ?? 0).toDouble(),
    longitude: (map['longitude'] ?? 0).toDouble(),
    roomType: RoomType.values.firstWhere(
      (e) => e.name == map['roomType'], orElse: () => RoomType.single),
    photos: List<String>.from(map['photos'] ?? []),
    videoUrl: map['videoUrl'],
    facilities: List<String>.from(map['facilities'] ?? []),
    isPublic: map['isPublic'] ?? true,
    status: RoomStatus.values.firstWhere(
      (e) => e.name == map['status'], orElse: () => RoomStatus.pending),
    createdAt: DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
    expiresAt: map['expiresAt'] != null ? DateTime.parse(map['expiresAt']) : null,
    rating: map['rating']?.toDouble(),
  );
}

// Available facilities
class RoomFacilities {
  static const List<String> all = [
    'पानी (Water)',
    'बिजली (Electricity)',
    'WiFi',
    'बाथरूम (Bathroom)',
    'किचन (Kitchen)',
    'पार्किंग (Parking)',
    'AC',
    'पंखा (Fan)',
    'कूलर (Cooler)',
    'फर्नीचर (Furniture)',
    'CCTV',
  ];
}

// Lead Model
enum LeadType { worker, room, land, house }

class LeadModel {
  final String id;
  final String title;
  final String description;
  final LeadType type;
  final String location;
  final double latitude;
  final double longitude;
  final String postedBy;
  final String posterPhone;
  final DateTime createdAt;
  final int pricePerLead; // in rupees (₹2)
  final bool isPurchased;

  LeadModel({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    required this.latitude,
    required this.longitude,
    required this.postedBy,
    required this.posterPhone,
    required this.createdAt,
    this.pricePerLead = 2,
    this.isPurchased = false,
  });

  String get typeDisplay {
    switch (type) {
      case LeadType.worker:
        return 'मजदूर चाहिए';
      case LeadType.room:
        return 'रूम चाहिए';
      case LeadType.land:
        return 'जमीन खरीदनी है';
      case LeadType.house:
        return 'घर खरीदना है';
    }
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'description': description,
    'type': type.name,
    'location': location,
    'latitude': latitude,
    'longitude': longitude,
    'postedBy': postedBy,
    'posterPhone': posterPhone,
    'createdAt': createdAt.toIso8601String(),
    'pricePerLead': pricePerLead,
    'isPurchased': isPurchased,
  };

  factory LeadModel.fromMap(Map<String, dynamic> map) => LeadModel(
    id: map['id'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    type: LeadType.values.firstWhere(
      (e) => e.name == map['type'], orElse: () => LeadType.worker),
    location: map['location'] ?? '',
    latitude: (map['latitude'] ?? 0).toDouble(),
    longitude: (map['longitude'] ?? 0).toDouble(),
    postedBy: map['postedBy'] ?? '',
    posterPhone: map['posterPhone'] ?? '',
    createdAt: DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
    pricePerLead: map['pricePerLead'] ?? 2,
    isPurchased: map['isPurchased'] ?? false,
  );
}

// Chat Message Model
class ChatMessage {
  final String id;
  final String senderId;
  final String receiverId;
  final String message;
  final DateTime timestamp;
  final bool isRead;

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.message,
    required this.timestamp,
    this.isRead = false,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'senderId': senderId,
    'receiverId': receiverId,
    'message': message,
    'timestamp': timestamp.toIso8601String(),
    'isRead': isRead,
  };

  factory ChatMessage.fromMap(Map<String, dynamic> map) => ChatMessage(
    id: map['id'] ?? '',
    senderId: map['senderId'] ?? '',
    receiverId: map['receiverId'] ?? '',
    message: map['message'] ?? '',
    timestamp: DateTime.parse(map['timestamp'] ?? DateTime.now().toIso8601String()),
    isRead: map['isRead'] ?? false,
  );
}
