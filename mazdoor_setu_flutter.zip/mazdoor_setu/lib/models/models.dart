// ─────────────────────────────────────────────
//  Models for Mazdoor Setu App
// ─────────────────────────────────────────────

enum UserRole { worker, thekedar, company, roomOwner }

enum VerificationStatus { pending, verified, rejected, notStarted }

enum WorkSkill {
  mason,
  painter,
  electrician,
  plumber,
  carpenter,
  welder,
  helper,
  driver,
  gardener,
  security,
  cleaner,
  cook,
  loader,
  tileWork,
  ironWork,
  unskilled,
}

extension WorkSkillExt on WorkSkill {
  String get label {
    switch (this) {
      case WorkSkill.mason:        return 'राज मिस्त्री (Mason)';
      case WorkSkill.painter:      return 'पेंटर (Painter)';
      case WorkSkill.electrician:  return 'इलेक्ट्रीशियन';
      case WorkSkill.plumber:      return 'प्लम्बर';
      case WorkSkill.carpenter:    return 'बढ़ई (Carpenter)';
      case WorkSkill.welder:       return 'वेल्डर (Welder)';
      case WorkSkill.helper:       return 'हेल्पर (Helper)';
      case WorkSkill.driver:       return 'ड्राइवर';
      case WorkSkill.gardener:     return 'माली (Gardener)';
      case WorkSkill.security:     return 'सिक्योरिटी गार्ड';
      case WorkSkill.cleaner:      return 'सफाई कर्मचारी';
      case WorkSkill.cook:         return 'रसोइया (Cook)';
      case WorkSkill.loader:       return 'लोडर (Loader)';
      case WorkSkill.tileWork:     return 'टाइल वर्क';
      case WorkSkill.ironWork:     return 'लोहा काम';
      case WorkSkill.unskilled:    return 'अनस्किल्ड (Unskilled)';
    }
  }
  String get emoji {
    switch (this) {
      case WorkSkill.mason:        return '🧱';
      case WorkSkill.painter:      return '🎨';
      case WorkSkill.electrician:  return '⚡';
      case WorkSkill.plumber:      return '🔧';
      case WorkSkill.carpenter:    return '🪚';
      case WorkSkill.welder:       return '🔥';
      case WorkSkill.helper:       return '🤝';
      case WorkSkill.driver:       return '🚗';
      case WorkSkill.gardener:     return '🌱';
      case WorkSkill.security:     return '🛡️';
      case WorkSkill.cleaner:      return '🧹';
      case WorkSkill.cook:         return '👨‍🍳';
      case WorkSkill.loader:       return '📦';
      case WorkSkill.tileWork:     return '🏠';
      case WorkSkill.ironWork:     return '⚙️';
      case WorkSkill.unskilled:    return '👷';
    }
  }
}

class AppUser {
  final String id;
  String name;
  String phone;
  UserRole role;
  VerificationStatus verificationStatus;
  String? profilePhoto;
  String? city;
  String? state;
  double? latitude;
  double? longitude;
  bool isOnline;
  bool isAvailableForWork;
  List<WorkSkill> skills;
  int freeCallsLeft;
  int freeChatsLeft;
  int walletBalance; // in paise (1 Rs = 100 paise)
  bool hasAcceptedPrivacyPolicy;
  DateTime? kycSubmittedAt;
  String? idProofType;
  String? idProofPath;
  String? selfiePhotoPath;
  DateTime createdAt;

  AppUser({
    required this.id,
    required this.name,
    required this.phone,
    required this.role,
    this.verificationStatus = VerificationStatus.notStarted,
    this.profilePhoto,
    this.city,
    this.state,
    this.latitude,
    this.longitude,
    this.isOnline = false,
    this.isAvailableForWork = false,
    this.skills = const [],
    this.freeCallsLeft = 2,
    this.freeChatsLeft = 3,
    this.walletBalance = 0,
    this.hasAcceptedPrivacyPolicy = false,
    this.kycSubmittedAt,
    this.idProofType,
    this.idProofPath,
    this.selfiePhotoPath,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  bool get isVerified => verificationStatus == VerificationStatus.verified;
  bool get canCall => isVerified && freeCallsLeft > 0;
  bool get canChat => isVerified && freeChatsLeft > 0;

  String get roleLabel {
    switch (role) {
      case UserRole.worker:    return 'मजदूर';
      case UserRole.thekedar:  return 'ठेकेदार';
      case UserRole.company:   return 'कंपनी';
      case UserRole.roomOwner: return 'रूम मालिक';
    }
  }

  String get roleEmoji {
    switch (role) {
      case UserRole.worker:    return '👷';
      case UserRole.thekedar:  return '🏗️';
      case UserRole.company:   return '🏢';
      case UserRole.roomOwner: return '🏠';
    }
  }
}

// ─── Room Model ─────────────────────────────
enum RoomStatus { saved, published, expired }
enum RoomType { single, shared, family, dormitory }

class RoomListing {
  final String id;
  final String ownerId;
  final String ownerName;
  final String ownerPhone;
  String title;
  String description;
  RoomType roomType;
  int pricePerMonth;
  String address;
  String city;
  double? latitude;
  double? longitude;
  List<String> facilities;
  List<String> photos;
  String? videoPath;
  RoomStatus status;
  DateTime? publishedAt;
  DateTime? expiresAt;
  bool isAvailable;
  int views;

  RoomListing({
    required this.id,
    required this.ownerId,
    required this.ownerName,
    required this.ownerPhone,
    required this.title,
    required this.description,
    required this.roomType,
    required this.pricePerMonth,
    required this.address,
    required this.city,
    this.latitude,
    this.longitude,
    this.facilities = const [],
    this.photos = const [],
    this.videoPath,
    this.status = RoomStatus.saved,
    this.publishedAt,
    this.expiresAt,
    this.isAvailable = true,
    this.views = 0,
  });

  bool get isLocked => status != RoomStatus.published;

  String get roomTypeLabel {
    switch (roomType) {
      case RoomType.single:    return 'सिंगल रूम';
      case RoomType.shared:    return 'शेयर्ड रूम';
      case RoomType.family:    return 'फैमिली रूम';
      case RoomType.dormitory: return 'डॉर्मिटरी';
    }
  }
}

// ─── Chat Model ─────────────────────────────
class ChatMessage {
  final String id;
  final String senderId;
  final String receiverId;
  final String message;
  final DateTime sentAt;
  bool isRead;
  MessageType type;

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.message,
    DateTime? sentAt,
    this.isRead = false,
    this.type = MessageType.text,
  }) : sentAt = sentAt ?? DateTime.now();
}

enum MessageType { text, image, location }

class ChatConversation {
  final String id;
  final String otherUserId;
  final String otherUserName;
  final String otherUserRole;
  final String otherUserPhone;
  String? lastMessage;
  DateTime? lastMessageAt;
  int unreadCount;
  bool isActive;

  ChatConversation({
    required this.id,
    required this.otherUserId,
    required this.otherUserName,
    required this.otherUserRole,
    required this.otherUserPhone,
    this.lastMessage,
    this.lastMessageAt,
    this.unreadCount = 0,
    this.isActive = true,
  });
}

// ─── Lead Model ─────────────────────────────
enum LeadType { worker, room, property, land, vehicle }

class Lead {
  final String id;
  String title;
  String description;
  LeadType type;
  String location;
  int pricePerLead;
  int totalLeads;
  int purchasedLeads;
  DateTime createdAt;
  bool isActive;

  Lead({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.location,
    this.pricePerLead = 200, // ₹2 = 200 paise
    this.totalLeads = 50,
    this.purchasedLeads = 0,
    DateTime? createdAt,
    this.isActive = true,
  }) : createdAt = createdAt ?? DateTime.now();

  String get typeLabel {
    switch (type) {
      case LeadType.worker:   return 'मजदूर चाहिए';
      case LeadType.room:     return 'किराये का कमरा';
      case LeadType.property: return 'घर खरीदना';
      case LeadType.land:     return 'खेत/जमीन';
      case LeadType.vehicle:  return 'वाहन किराये पर';
    }
  }
  String get typeEmoji {
    switch (type) {
      case LeadType.worker:   return '👷';
      case LeadType.room:     return '🏠';
      case LeadType.property: return '🏘️';
      case LeadType.land:     return '🌾';
      case LeadType.vehicle:  return '🚛';
    }
  }
}

// ─── Subscription Plan ──────────────────────
class SubscriptionPlan {
  final String id;
  final String name;
  final int priceInRupees;
  final int durationDays;
  final int callsIncluded;
  final int chatsIncluded;
  final List<String> features;
  final bool isPopular;

  const SubscriptionPlan({
    required this.id,
    required this.name,
    required this.priceInRupees,
    required this.durationDays,
    required this.callsIncluded,
    required this.chatsIncluded,
    required this.features,
    this.isPopular = false,
  });
}

const List<SubscriptionPlan> kSubscriptionPlans = [
  SubscriptionPlan(
    id: 'basic',
    name: 'बेसिक',
    priceInRupees: 49,
    durationDays: 30,
    callsIncluded: 10,
    chatsIncluded: 20,
    features: [
      '10 कॉल / महीना',
      '20 चैट / महीना',
      'Basic Profile',
      'Normal Support',
    ],
  ),
  SubscriptionPlan(
    id: 'standard',
    name: 'स्टैंडर्ड',
    priceInRupees: 99,
    durationDays: 30,
    callsIncluded: 30,
    chatsIncluded: 60,
    features: [
      '30 कॉल / महीना',
      '60 चैट / महीना',
      'Featured Profile',
      'Priority Support',
      '5 Free Leads',
    ],
    isPopular: true,
  ),
  SubscriptionPlan(
    id: 'premium',
    name: 'प्रीमियम',
    priceInRupees: 199,
    durationDays: 30,
    callsIncluded: 999,
    chatsIncluded: 999,
    features: [
      'Unlimited कॉल',
      'Unlimited चैट',
      'Top Listing Priority',
      'Dedicated Support',
      '20 Free Leads',
      'Verified Badge',
    ],
  ),
];

// ─── Mock Data ──────────────────────────────
List<AppUser> getMockWorkers() {
  return [
    AppUser(
      id: 'w1',
      name: 'Ramesh Kumar',
      phone: '9876543210',
      role: UserRole.worker,
      verificationStatus: VerificationStatus.verified,
      city: 'Delhi',
      state: 'Delhi',
      isOnline: true,
      isAvailableForWork: true,
      skills: [WorkSkill.mason, WorkSkill.tileWork],
      freeCallsLeft: 2,
      freeChatsLeft: 3,
    ),
    AppUser(
      id: 'w2',
      name: 'Suresh Yadav',
      phone: '9123456780',
      role: UserRole.worker,
      verificationStatus: VerificationStatus.verified,
      city: 'Noida',
      state: 'UP',
      isOnline: true,
      isAvailableForWork: true,
      skills: [WorkSkill.electrician, WorkSkill.helper],
    ),
    AppUser(
      id: 'w3',
      name: 'Mohan Singh',
      phone: '8987654321',
      role: UserRole.worker,
      verificationStatus: VerificationStatus.verified,
      city: 'Gurugram',
      state: 'Haryana',
      isOnline: false,
      isAvailableForWork: false,
      skills: [WorkSkill.plumber, WorkSkill.carpenter],
    ),
    AppUser(
      id: 'w4',
      name: 'Rajesh Patel',
      phone: '7856341290',
      role: UserRole.worker,
      verificationStatus: VerificationStatus.verified,
      city: 'Mumbai',
      state: 'Maharashtra',
      isOnline: true,
      isAvailableForWork: true,
      skills: [WorkSkill.painter, WorkSkill.helper],
    ),
    AppUser(
      id: 'w5',
      name: 'Dinesh Gupta',
      phone: '9654321870',
      role: UserRole.worker,
      verificationStatus: VerificationStatus.pending,
      city: 'Delhi',
      state: 'Delhi',
      isOnline: false,
      isAvailableForWork: true,
      skills: [WorkSkill.driver, WorkSkill.loader],
    ),
    AppUser(
      id: 'w6',
      name: 'Pappu Mishra',
      phone: '8741236540',
      role: UserRole.thekedar,
      verificationStatus: VerificationStatus.verified,
      city: 'Lucknow',
      state: 'UP',
      isOnline: true,
      isAvailableForWork: false,
      skills: [],
    ),
  ];
}

List<RoomListing> getMockRooms() {
  return [
    RoomListing(
      id: 'r1',
      ownerId: 'ro1',
      ownerName: 'Harish Sharma',
      ownerPhone: '9812345670',
      title: 'सिंगल रूम - लेबर कॉलोनी, नोएडा',
      description: 'साफ और सुरक्षित सिंगल रूम। पानी और बिजली 24 घंटे। मेट्रो स्टेशन पास।',
      roomType: RoomType.single,
      pricePerMonth: 3500,
      address: 'Sector 62, Labour Colony, Noida',
      city: 'Noida',
      facilities: ['पानी', 'बिजली', 'WiFi', 'किचन'],
      status: RoomStatus.published,
      isAvailable: true,
      views: 45,
    ),
    RoomListing(
      id: 'r2',
      ownerId: 'ro2',
      ownerName: 'Sunita Devi',
      ownerPhone: '9876540123',
      title: 'शेयर्ड रूम - 4 मजदूर के लिए',
      description: '4 लोगों के लिए शेयर्ड रूम। अच्छी सुविधाएं। ₹1500 प्रति व्यक्ति।',
      roomType: RoomType.shared,
      pricePerMonth: 1500,
      address: 'Govindpuri, Delhi',
      city: 'Delhi',
      facilities: ['पानी', 'बिजली', 'शौचालय'],
      status: RoomStatus.published,
      isAvailable: true,
      views: 78,
    ),
    RoomListing(
      id: 'r3',
      ownerId: 'ro3',
      ownerName: 'Mahesh Joshi',
      ownerPhone: '8745612390',
      title: 'फैमिली रूम - Gurugram',
      description: 'फैमिली के लिए 1BHK। शांत इलाका। School और Market पास।',
      roomType: RoomType.family,
      pricePerMonth: 7000,
      address: 'DLF Phase 2, Gurugram',
      city: 'Gurugram',
      facilities: ['पानी', 'बिजली', 'WiFi', 'पार्किंग', 'बालकनी'],
      status: RoomStatus.published,
      isAvailable: true,
      views: 32,
    ),
    RoomListing(
      id: 'r4',
      ownerId: 'ro4',
      ownerName: 'Ramkali Devi',
      ownerPhone: '9632145870',
      title: 'डॉर्मिटरी - 10 बिस्तर',
      description: '10 मजदूरों के लिए डॉर्मिटरी। सुरक्षित एरिया। साइट से 5 मिनट।',
      roomType: RoomType.dormitory,
      pricePerMonth: 1000,
      address: 'Okhla Industrial Area, Delhi',
      city: 'Delhi',
      facilities: ['पानी', 'बिजली', 'पंखा', 'लॉकर'],
      status: RoomStatus.saved,
      isAvailable: true,
      views: 0,
    ),
  ];
}

List<Lead> getMockLeads() {
  return [
    Lead(
      id: 'l1',
      title: 'मजदूर चाहिए - Construction Site Delhi',
      description: 'Delhi Rohini में 20 मजदूर चाहिए। Mason और Helper। 3 महीने काम।',
      type: LeadType.worker,
      location: 'Rohini, Delhi',
      totalLeads: 20,
      purchasedLeads: 8,
    ),
    Lead(
      id: 'l2',
      title: 'घर खरीदना है - Budget 30 Lakh',
      description: 'Noida या Greater Noida में 2BHK। Budget 25-30 Lakh।',
      type: LeadType.property,
      location: 'Noida',
      totalLeads: 5,
      purchasedLeads: 2,
    ),
    Lead(
      id: 'l3',
      title: 'खेत किराये पर चाहिए',
      description: 'UP में 5-10 बीघा खेत किराये पर चाहिए। Wheat farming के लिए।',
      type: LeadType.land,
      location: 'Agra, UP',
      totalLeads: 3,
      purchasedLeads: 0,
    ),
    Lead(
      id: 'l4',
      title: 'किराये का कमरा चाहिए - Worker',
      description: 'Gurugram में single room। Max ₹3000/month। Metro के पास।',
      type: LeadType.room,
      location: 'Gurugram, Haryana',
      totalLeads: 10,
      purchasedLeads: 4,
    ),
  ];
}
