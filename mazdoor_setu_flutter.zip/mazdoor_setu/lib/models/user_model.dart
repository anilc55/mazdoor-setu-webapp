enum UserRole { worker, thekedar, company, roomOwner }

enum VerificationStatus { pending, verified, rejected, notStarted }

class UserModel {
  final String uid;
  final String name;
  final String phone;
  final UserRole role;
  final String? profileImage;
  final String? location;
  final double? latitude;
  final double? longitude;
  final VerificationStatus verificationStatus;
  final List<String> skills;
  final bool isAvailableForWork;
  final bool isOnline;
  final int freeCallsLeft;
  final int freeChatsLeft;
  final int walletBalance; // in paise
  final String? aadharUrl;
  final String? selfieUrl;
  final String? panUrl;
  final DateTime createdAt;
  final String? bio;
  final double rating;
  final int totalRatings;

  UserModel({
    required this.uid,
    required this.name,
    required this.phone,
    required this.role,
    this.profileImage,
    this.location,
    this.latitude,
    this.longitude,
    this.verificationStatus = VerificationStatus.notStarted,
    this.skills = const [],
    this.isAvailableForWork = false,
    this.isOnline = false,
    this.freeCallsLeft = 2,
    this.freeChatsLeft = 3,
    this.walletBalance = 0,
    this.aadharUrl,
    this.selfieUrl,
    this.panUrl,
    required this.createdAt,
    this.bio,
    this.rating = 0.0,
    this.totalRatings = 0,
  });

  bool get isVerified => verificationStatus == VerificationStatus.verified;

  String get roleDisplayName {
    switch (role) {
      case UserRole.worker:
        return 'मजदूर';
      case UserRole.thekedar:
        return 'ठेकेदार';
      case UserRole.company:
        return 'कंपनी';
      case UserRole.roomOwner:
        return 'रूम ओनर';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'phone': phone,
      'role': role.name,
      'profileImage': profileImage,
      'location': location,
      'latitude': latitude,
      'longitude': longitude,
      'verificationStatus': verificationStatus.name,
      'skills': skills,
      'isAvailableForWork': isAvailableForWork,
      'isOnline': isOnline,
      'freeCallsLeft': freeCallsLeft,
      'freeChatsLeft': freeChatsLeft,
      'walletBalance': walletBalance,
      'aadharUrl': aadharUrl,
      'selfieUrl': selfieUrl,
      'panUrl': panUrl,
      'createdAt': createdAt.toIso8601String(),
      'bio': bio,
      'rating': rating,
      'totalRatings': totalRatings,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      role: UserRole.values.firstWhere(
        (e) => e.name == map['role'],
        orElse: () => UserRole.worker,
      ),
      profileImage: map['profileImage'],
      location: map['location'],
      latitude: map['latitude']?.toDouble(),
      longitude: map['longitude']?.toDouble(),
      verificationStatus: VerificationStatus.values.firstWhere(
        (e) => e.name == map['verificationStatus'],
        orElse: () => VerificationStatus.notStarted,
      ),
      skills: List<String>.from(map['skills'] ?? []),
      isAvailableForWork: map['isAvailableForWork'] ?? false,
      isOnline: map['isOnline'] ?? false,
      freeCallsLeft: map['freeCallsLeft'] ?? 2,
      freeChatsLeft: map['freeChatsLeft'] ?? 3,
      walletBalance: map['walletBalance'] ?? 0,
      aadharUrl: map['aadharUrl'],
      selfieUrl: map['selfieUrl'],
      panUrl: map['panUrl'],
      createdAt: DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
      bio: map['bio'],
      rating: (map['rating'] ?? 0.0).toDouble(),
      totalRatings: map['totalRatings'] ?? 0,
    );
  }

  UserModel copyWith({
    String? name,
    String? profileImage,
    String? location,
    double? latitude,
    double? longitude,
    VerificationStatus? verificationStatus,
    List<String>? skills,
    bool? isAvailableForWork,
    bool? isOnline,
    int? freeCallsLeft,
    int? freeChatsLeft,
    int? walletBalance,
    String? aadharUrl,
    String? selfieUrl,
    String? panUrl,
    String? bio,
    double? rating,
    int? totalRatings,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      phone: phone,
      role: role,
      profileImage: profileImage ?? this.profileImage,
      location: location ?? this.location,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      skills: skills ?? this.skills,
      isAvailableForWork: isAvailableForWork ?? this.isAvailableForWork,
      isOnline: isOnline ?? this.isOnline,
      freeCallsLeft: freeCallsLeft ?? this.freeCallsLeft,
      freeChatsLeft: freeChatsLeft ?? this.freeChatsLeft,
      walletBalance: walletBalance ?? this.walletBalance,
      aadharUrl: aadharUrl ?? this.aadharUrl,
      selfieUrl: selfieUrl ?? this.selfieUrl,
      panUrl: panUrl ?? this.panUrl,
      createdAt: createdAt,
      bio: bio ?? this.bio,
      rating: rating ?? this.rating,
      totalRatings: totalRatings ?? this.totalRatings,
    );
  }
}

// All skills available in the app
class AppSkills {
  static const List<String> allSkills = [
    'राजमिस्त्री (Mason)',
    'पेंटर (Painter)',
    'हेल्पर (Helper)',
    'इलेक्ट्रीशियन (Electrician)',
    'प्लंबर (Plumber)',
    'कारपेंटर (Carpenter)',
    'वेल्डर (Welder)',
    'टाइल मिस्त्री (Tile Fitter)',
    'लोहार (Blacksmith)',
    'ड्राइवर (Driver)',
    'गार्ड (Security Guard)',
    'माली (Gardener)',
    'सफाई कर्मी (Sweeper)',
    'कुक (Cook)',
    'फर्नीचर मेकर (Furniture Maker)',
    'AC मैकेनिक',
    'मोबाइल रिपेयर',
    'अनस्किल्ड (Unskilled)',
  ];
}
