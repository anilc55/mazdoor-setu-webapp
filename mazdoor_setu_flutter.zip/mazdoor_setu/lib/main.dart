import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'screens/splash_screen.dart';
import 'screens/privacy_policy_screen.dart';
import 'screens/login_screen.dart';
import 'screens/otp_screen.dart';
import 'screens/role_selection_screen.dart';
import 'screens/kyc_screen.dart';
import 'screens/home_screen.dart';
import 'screens/worker_listing_screen.dart';
import 'screens/room_listing_screen.dart';
import 'screens/add_room_screen.dart';
import 'screens/chat_list_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/payment_screen.dart';
import 'screens/lead_screen.dart';
import 'screens/worker_detail_screen.dart';
import 'screens/room_detail_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const MazdoorSetuApp());
}

class MazdoorSetuApp extends StatelessWidget {
  const MazdoorSetuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: MaterialApp(
        title: 'मजदूर सेतु',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        initialRoute: '/splash',
        routes: {
          '/splash': (ctx) => const SplashScreen(),
          '/privacy': (ctx) => const PrivacyPolicyScreen(),
          '/login': (ctx) => const LoginScreen(),
          '/otp': (ctx) => const OtpScreen(),
          '/role-selection': (ctx) => const RoleSelectionScreen(),
          '/kyc': (ctx) => const KycScreen(),
          '/home': (ctx) => const HomeScreen(),
          '/workers': (ctx) => const WorkerListingScreen(),
          '/rooms': (ctx) => const RoomListingScreen(),
          '/add-room': (ctx) => const AddRoomScreen(),
          '/chats': (ctx) => const ChatListScreen(),
          '/chat': (ctx) => const ChatScreen(),
          '/profile': (ctx) => const ProfileScreen(),
          '/payment': (ctx) => const PaymentScreen(),
          '/leads': (ctx) => const LeadScreen(),
          '/worker-detail': (ctx) => const WorkerDetailScreen(),
          '/room-detail': (ctx) => const RoomDetailScreen(),
        },
      ),
    );
  }
}
